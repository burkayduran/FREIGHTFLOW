import React, { useState, useEffect, useRef, useCallback } from "react";
const returnReact = React;

/* HELPERS */
const money=(v,ccy="USD",lang="tr")=>{if(v===null||v===undefined||isNaN(v))return"—";return new Intl.NumberFormat(lang==="tr"?"tr-TR":"en-US",{style:"currency",currency:ccy,maximumFractionDigits:0}).format(v);};
const ymd=(d)=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
const ymdhm=(d)=>ymd(d)+" "+String(d.getHours()).padStart(2,"0")+":"+String(d.getMinutes()).padStart(2,"0");
const localNow=()=>ymdhm(new Date());
const todayStr=()=>ymd(new Date());
const isBeforeToday=(s)=>s?s.slice(0,10)<todayStr():false;
const daysDiff=(a,b)=>{if(!a||!b)return null;return Math.round((new Date(a+"T00:00:00")-new Date(b+"T00:00:00"))/86400000);};
const hoursDiff=(w)=>{if(!w)return 9999;try{return(Date.now()-new Date(w.replace(" ","T")).getTime())/3600000;}catch(e){return 9999;}};
const safeHoursUntil=(w)=>{if(!w)return 9999;try{return(new Date(w.replace(" ","T")).getTime()-Date.now())/3600000;}catch(e){return 9999;}};
const val=(x,y,z=0)=>(x??y??z);
const fmtDate=(d)=>d?d.slice(5).replace("-","/"):"—";
const fmtDateTime=(d)=>d?d.slice(5,16).replace("-","/"):"—";
const fmtSla=(s)=>!s?"—":s.length>10?fmtDateTime(s):fmtDate(s);
const pct=(cost,rev)=>{if(!rev||rev<=0)return"—";return(((rev-(cost||0))/rev)*100).toFixed(0)+"%";};
const uid=()=>Math.random().toString(36).slice(2,10);
const hasMixedCcy=(b)=>new Set((b.charges||[]).map(c=>c.ccy)).size>1;
const isSlaOverdue=(sla)=>{if(!sla)return false;return sla.length>10?sla<localNow():isBeforeToday(sla);};
const slaToMs=(sla)=>{if(!sla)return 9e15;try{return new Date((sla.length>10?sla.replace(" ","T"):sla+"T23:59")).getTime();}catch(e){return 9e15;}};
const getLastActionWhen=(b)=>{const t=(b.auditLog||[]).map(a=>a.when).filter(Boolean);return t.length?t.reduce((a,c)=>a>c?a:c):null;};

/* THEMES */
const TH={light:{sidebar:"#fff",sidebarBorder:"#e5e8ed",sidebarActive:"#eef3ff",bg:"#f3f5f8",cardBg:"#fff",cardBorder:"#e5e8ed",surface:"#f0f2f5",surfaceAlt:"#f8f9fb",text:"#1a2332",textSecondary:"#4a5568",textMuted:"#7a8599",accent:"#2563eb",accentSoft:"#dbeafe",accentBg:"#2563eb0c",gradient:"linear-gradient(135deg,#2563eb,#1e50c8)",gradientText:"#fff",success:"#0d9e42",successBg:"#ecfdf3",danger:"#d92b2b",dangerBg:"#fef2f2",warning:"#b47108",warningBg:"#fffbeb",purple:"#7c3aed",purpleBg:"#f3f0ff",pink:"#c2298a",pinkBg:"#fdf2f8",cyan:"#0882a0",cyanBg:"#ecfeff",hover:"#f0f4ff",inputBg:"#f3f5f8",inputBorder:"#dde1e8",divider:"#e5e8ed",shadow:"0 1px 3px rgba(0,0,0,.06)",overdueBg:"#fef8f8",backdrop:"rgba(0,0,0,.3)",phaseBg:["#eff6ff","#ecfdf5","#fefce8","#fef2f2","#f5f3ff"],blocked:"#e5e8ed"},dark:{sidebar:"#1a1a21",sidebarBorder:"#2a2a33",sidebarActive:"#1e2438",bg:"#202028",cardBg:"#27272f",cardBorder:"#333340",surface:"#1e1e26",surfaceAlt:"#232330",text:"#e0ddd8",textSecondary:"#a09c96",textMuted:"#8b8790",accent:"#60a5fa",accentSoft:"#60a5fa20",accentBg:"#60a5fa0c",gradient:"linear-gradient(135deg,#60a5fa,#3b82f6)",gradientText:"#ffffff",success:"#6fb87e",successBg:"#6fb87e14",danger:"#e87c75",dangerBg:"#e87c7514",warning:"#d4a34a",warningBg:"#d4a34a14",purple:"#a78bfa",purpleBg:"#a78bfa14",pink:"#f472b6",pinkBg:"#f472b614",cyan:"#67e8f9",cyanBg:"#67e8f914",hover:"#2d2d3a",inputBg:"#1a1a21",inputBorder:"#333340",divider:"#2a2a33",shadow:"0 1px 3px rgba(0,0,0,.2)",overdueBg:"#e87c7514",backdrop:"rgba(0,0,0,.6)",phaseBg:["#1e2438","#1a2d22","#2d2a1a","#2d1a1a","#241e38"],blocked:"#333340"}};

/* LANG */
const L={tr:{bookings:"Bookings",customers:"Müşteriler",settings:"Ayarlar",workflow:"İş Akışı",admin:"Admin Panel",booker:"Operasyon",newBooking:"+ Yeni Booking",search:"Ara... (⌘K)",allBookings:"Tüm Bookings",export:"İhracat",import:"İthalat",transit:"Transit",crossTrade:"Cross-trade",quote:"Teklif",confirmed:"Onay",loading:"Yükleme",inTransit:"Transit",arrived:"Varış",delivered:"Teslim",back:"← Geri",total:"Toplam",active:"Aktif",avgMargin:"Ort. Marj",all:"Tümü",direction:"Yön",overdue:"Gecikmiş",cost:"Alış",revenue:"Satış",profit:"Kâr",margin:"Marj",overdueTasks:"Gecikmiş",lowMargin:"Düşük Marj",workflowTab:"İş Akışı",detailTab:"Detay",phaseA:"Booking & Kurulum",phaseB:"Ekipman & Ön Nakliye",phaseC:"Doküman Cutoff",phaseD:"Liman & Çıkış",phaseE:"Çıkış Sonrası & Finans",phaseA_imp:"Pre-alert & Kurulum",phaseB_imp:"Varış & DO",phaseC_imp:"Gümrük & Teslimat",phaseD_imp:"D&D Koruması",phaseE_imp:"Finans",taskDone:"Tamamlandı",taskOverdue:"Gecikmiş",markComplete:"Tamamla",auto:"Oto",semiAuto:"Y.Oto",manual:"Manuel",sla:"SLA",evidence:"Kanıt",addEvidence:"Not/kanıt...",adminTitle:"Admin Kontrol Paneli",bookerTitle:"Operasyon Paneli",exceptionsBoard:"İstisnalar",workload:"İş Yükleri",auditTrail:"Aktivite İzi",storyMode:"Olay Akışı",forensicMode:"Detay Arama",agingFiles:"48+ Saat Aksiyonsuz",openTasks:"Açık",dueToday:"Bugün",overdueCount:"Gecikmiş",completedToday:"Bugün Biten",fileRef:"Dosya",task:"Görev",owner:"Sorumlu",assignee:"Atanan",noOverdue:"Gecikmiş yok ✓",noAging:"Aktif ✓",progress:"İlerleme",phase:"Faz",days:"gün",hours:"saat",blocked:"Engelli",blockedBy:"Önce:",required:"Zorunlu",optional:"Opsiyonel",openFile:"Dosyaya Git",reassign:"Yeniden Ata",nudge:"Hatırlat",lastAction:"Son Aksiyon",cancel:"İptal",save:"Kaydet",noteRequired:"Not zorunludur",general:"Genel",datesVessel:"Tarihler & Gemi",containers:"Konteynerler",finance:"Finans",documents:"Dokümanlar",tracking:"Track & Trace",notes:"Notlar",customer:"Müşteri",agent:"Agent",shipper:"Shipper",consignee:"Consignee",incoterm:"Incoterm",commodity:"Emtia",planned:"Planlanan",actual:"Gerçekleşen",vessel:"Gemi",voyage:"Sefer",etd:"ETD",eta:"ETA",type:"Tip",weight:"Ağırlık",sealNo:"Mühür",addDoc:"+ Doküman",addNote:"+ Not",totalBuy:"Alış",totalSell:"Satış",netProfit:"Kâr",chargeLines:"Maliyet",chargeType:"Kalem",buySell:"A/S",vendor:"Tedarikçi",amount:"Tutar",status:"Durum",mixedCcy:"Karışık Döviz",mixedCcyWarn:"FX olmadan toplam gösterilemiyor",upload:"Yükle",uploadDoc:"Doküman Yükle",selectFile:"Dosya Seç",version:"Versiyon",preview:"Önizleme",download:"İndir",share:"Paylaş",close:"Kapat",hbl:"HBL",mbl:"MBL",packing:"Packing List",invoice:"Invoice",vgm:"VGM",booking_conf:"Booking Conf.",cmr:"CMR",other:"Diğer",draft_bl:"Draft BL",final_bl:"Final BL",do_doc:"Delivery Order",pod:"POD",si:"SI",arrival_notice:"Arrival Notice",myTasks:"Görevlerim",allFiles:"Tüm Dosyalar",reassignTo:"Ata →",nudged:"hatırlatıldı",reassigned:"yeniden atandı",completeness:"Veri Tamamlılığı",goToSection:"Git →",requiredDocs:"Zorunlu Dökümanlar",missingRequired:"eksik zorunlu",vessel_missing:"Gemi yok",eta_missing:"ETA yok",vgm_missing:"VGM bekleniyor",docs_missing:"Doküman yok",consignee_missing:"Consignee eksik",noData:"Veri yok",quickUpdate:"Hızlı Güncelleme",quickUpdateBtn:"⚡ Güncelle",eventType:"Olay Tipi",rolled:"Rolled",etdChanged:"ETD Değişti",etaChanged:"ETA Değişti",cutoffUpdated:"Cutoff Güncellendi",equipmentDelay:"Ekipman Gecikmesi",newETD:"Yeni ETD",newETA:"Yeni ETA",newVessel:"Yeni Gemi",newVoyage:"Yeni Sefer",siCutoff:"SI Cutoff",vgmCutoff:"VGM Cutoff",cyCutoff:"CY Cutoff",emptyEarliest:"En Erken Empty",note:"Not",source:"Kaynak",manualSrc:"Manuel",carrierNotice:"Taşıyıcı",systemSrc:"Sistem",impactPreview:"Etki Önizlemesi",tasksAffected:"Etkilenen Görev",oldSla:"Eski SLA",newSla:"Yeni SLA",noImpact:"Değişiklik yok",schedule:"Program",cutoffs:"Cutoff'lar",equipment:"Ekipman",severity:"Önem",critical:"Kritik",warn:"Uyarı",siCutoffNear:"SI cutoff <24s, tamamlanmadı",vgmCutoffNear:"VGM cutoff <24s, tamamlanmadı",cyCutoffNear:"CY cutoff <24s, gate-in yok",emptyOverdue:"Empty geçti, pickup yok",etdNear:"ETD <48s, sailed değil",jumpToSection:"Bölüme Git",allCategories:"Tümü",scheduleEvt:"Program",docsEvt:"Doküman",taskEvt:"Görev",financeEvt:"Finans",filterWho:"Kim"},
en:{bookings:"Bookings",customers:"Customers",settings:"Settings",workflow:"Workflow",admin:"Admin Panel",booker:"Operations",newBooking:"+ New Booking",search:"Search... (⌘K)",allBookings:"All Bookings",export:"Export",import:"Import",transit:"Transit",crossTrade:"Cross-trade",quote:"Quote",confirmed:"Confirmed",loading:"Loading",inTransit:"In Transit",arrived:"Arrived",delivered:"Delivered",back:"← Back",total:"Total",active:"Active",avgMargin:"Avg Margin",all:"All",direction:"Dir",overdue:"Overdue",cost:"Cost",revenue:"Revenue",profit:"Profit",margin:"Margin",overdueTasks:"Overdue",lowMargin:"Low Margin",workflowTab:"Workflow",detailTab:"Detail",phaseA:"Booking & Setup",phaseB:"Equipment & Pre-carriage",phaseC:"Document Cutoffs",phaseD:"Port & Departure",phaseE:"Post-departure & Finance",phaseA_imp:"Pre-alert & Setup",phaseB_imp:"Arrival & DO",phaseC_imp:"Customs & Delivery",phaseD_imp:"D&D Protection",phaseE_imp:"Finance",taskDone:"Completed",taskOverdue:"Overdue",markComplete:"Complete",auto:"Auto",semiAuto:"Semi",manual:"Manual",sla:"SLA",evidence:"Evidence",addEvidence:"Note/evidence...",adminTitle:"Admin Control Panel",bookerTitle:"Operations Panel",exceptionsBoard:"Exceptions",workload:"Workload",auditTrail:"Audit Trail",storyMode:"Story",forensicMode:"Forensic",agingFiles:"48+ Hrs No Action",openTasks:"Open",dueToday:"Today",overdueCount:"Overdue",completedToday:"Done Today",fileRef:"File",task:"Task",owner:"Owner",assignee:"Assignee",noOverdue:"No overdue ✓",noAging:"Active ✓",progress:"Progress",phase:"Phase",days:"days",hours:"hrs",blocked:"Blocked",blockedBy:"Requires:",required:"Required",optional:"Optional",openFile:"Open File",reassign:"Reassign",nudge:"Nudge",lastAction:"Last Action",cancel:"Cancel",save:"Save",noteRequired:"Note required",general:"General",datesVessel:"Dates & Vessel",containers:"Containers",finance:"Finance",documents:"Documents",tracking:"Track & Trace",notes:"Notes",customer:"Customer",agent:"Agent",shipper:"Shipper",consignee:"Consignee",incoterm:"Incoterm",commodity:"Commodity",planned:"Planned",actual:"Actual",vessel:"Vessel",voyage:"Voyage",etd:"ETD",eta:"ETA",type:"Type",weight:"Weight",sealNo:"Seal",addDoc:"+ Document",addNote:"+ Note",totalBuy:"Buy",totalSell:"Sell",netProfit:"Profit",chargeLines:"Charges",chargeType:"Charge",buySell:"B/S",vendor:"Vendor",amount:"Amount",status:"Status",mixedCcy:"Mixed Ccy",mixedCcyWarn:"No FX totals",upload:"Upload",uploadDoc:"Upload Document",selectFile:"Select File",version:"Version",preview:"Preview",download:"Download",share:"Share",close:"Close",hbl:"HBL",mbl:"MBL",packing:"Packing List",invoice:"Invoice",vgm:"VGM",booking_conf:"Booking Conf.",cmr:"CMR",other:"Other",draft_bl:"Draft BL",final_bl:"Final BL",do_doc:"Delivery Order",pod:"POD",si:"SI",arrival_notice:"Arrival Notice",myTasks:"My Tasks",allFiles:"All Files",reassignTo:"Assign →",nudged:"nudged",reassigned:"reassigned",completeness:"Completeness",goToSection:"Go →",requiredDocs:"Required Docs",missingRequired:"missing required",vessel_missing:"Vessel missing",eta_missing:"ETA missing",vgm_missing:"VGM pending",docs_missing:"No documents",consignee_missing:"Consignee missing",noData:"No data",quickUpdate:"Quick Update",quickUpdateBtn:"⚡ Update",eventType:"Event Type",rolled:"Rolled",etdChanged:"ETD Changed",etaChanged:"ETA Changed",cutoffUpdated:"Cutoff Updated",equipmentDelay:"Equipment Delay",newETD:"New ETD",newETA:"New ETA",newVessel:"New Vessel",newVoyage:"New Voyage",siCutoff:"SI Cutoff",vgmCutoff:"VGM Cutoff",cyCutoff:"CY Cutoff",emptyEarliest:"Earliest Empty",note:"Note",source:"Source",manualSrc:"Manual",carrierNotice:"Carrier",systemSrc:"System",impactPreview:"Impact Preview",tasksAffected:"Tasks Affected",oldSla:"Old SLA",newSla:"New SLA",noImpact:"No changes",schedule:"Schedule",cutoffs:"Cutoffs",equipment:"Equipment",severity:"Severity",critical:"Critical",warn:"Warning",siCutoffNear:"SI cutoff <24h, not done",vgmCutoffNear:"VGM cutoff <24h, not done",cyCutoffNear:"CY cutoff <24h, no gate-in",emptyOverdue:"Empty passed, no pickup",etdNear:"ETD <48h, not sailed",jumpToSection:"Jump",allCategories:"All",scheduleEvt:"Schedule",docsEvt:"Docs",taskEvt:"Task",financeEvt:"Finance",filterWho:"Who"}};
const OWNER_L={tr:{ops:"Ops",sales:"Satış",docs:"Dok.",finance:"Finans",customs:"Gümrük",system:"Sistem"},en:{ops:"Ops",sales:"Sales",docs:"Docs",finance:"Finance",customs:"Customs",system:"System"}};
const EVENT_TYPES=["ROLLED","ETD_CHANGED","ETA_CHANGED","CUTOFF_UPDATED","EQUIPMENT_DELAY"];
const EVENT_LBL={tr:{ROLLED:"Rolled",ETD_CHANGED:"ETD Değişti",ETA_CHANGED:"ETA Değişti",CUTOFF_UPDATED:"Cutoff Güncel",EQUIPMENT_DELAY:"Ekipman Gecikme"},en:{ROLLED:"Rolled",ETD_CHANGED:"ETD Changed",ETA_CHANGED:"ETA Changed",CUTOFF_UPDATED:"Cutoff Updated",EQUIPMENT_DELAY:"Equipment Delay"}};

/* TEMPLATES (slaRefs updated: SI→siCutoff, VGM→vgmCutoff, Gate-in→cyCutoff, Empty→emptyEarliest) */
const EX_TPL=[
{phase:"A",tasks:[
{id:"e-a1",text:"Dosya oluşturuldu",textEn:"File created",type:"auto",slaRef:"booking",slaOffset:0,slaUnit:"h",criteria:"Dosya açıldı",criteriaEn:"File created",owner:"ops",evReq:false,autoRule:"fileCreated"},
{id:"e-a2",text:"Buy/Sell kilitlendi",textEn:"Buy/Sell locked",type:"semi",slaRef:"booking",slaOffset:2,slaUnit:"h",criteria:"Charge girildi",criteriaEn:"Charges entered",owner:"sales",evReq:true},
{id:"e-a3",text:"Taraflar doğrulandı",textEn:"Parties verified",type:"semi",slaRef:"booking",slaOffset:4,slaUnit:"h",criteria:"Alanlar tamam",criteriaEn:"Fields complete",owner:"ops",evReq:false},
{id:"e-a4",text:"Carrier booking teyidi",textEn:"Carrier confirmed",type:"semi",slaRef:"booking",slaOffset:6,slaUnit:"h",criteria:"Carrier ref",criteriaEn:"Carrier ref",owner:"ops",evReq:true},
]},
{phase:"B",tasks:[
{id:"e-b1",text:"Container pickup planlandı",textEn:"Container pickup planned",type:"manual",slaRef:"emptyEarliest",slaOffset:0,slaUnit:"h",criteria:"Pickup + vendor",criteriaEn:"Pickup + vendor",owner:"ops",evReq:true},
{id:"e-b2",text:"Trucking teyit edildi",textEn:"Trucking confirmed",type:"semi",slaRef:"etd",slaOffset:-3,slaUnit:"d",criteria:"Vendor + tarih",criteriaEn:"Vendor + date",owner:"ops",evReq:true},
]},
{phase:"C",tasks:[
{id:"e-c1",text:"SI alındı",textEn:"SI received",type:"semi",slaRef:"siCutoff",slaOffset:0,slaUnit:"h",criteria:"SI yüklendi",criteriaEn:"SI uploaded",owner:"docs",evReq:false},
{id:"e-c2",text:"VGM alındı",textEn:"VGM received",type:"semi",slaRef:"vgmCutoff",slaOffset:0,slaUnit:"h",criteria:"VGM + alanlar",criteriaEn:"VGM + fields",owner:"ops",evReq:false},
{id:"e-c3",text:"Draft BL hazırlandı",textEn:"Draft BL prepared",type:"auto",slaRef:"etd",slaOffset:-2,slaUnit:"d",criteria:"Draft BL yüklendi",criteriaEn:"Draft BL uploaded",owner:"docs",evReq:false,autoRule:"draftBLUploaded"},
{id:"e-c4",text:"Draft BL onayı",textEn:"Draft BL approval",type:"semi",slaRef:"etd",slaOffset:-1,slaUnit:"d",criteria:"Onay notu",criteriaEn:"Approval note",owner:"ops",evReq:true,dependsOn:["e-c3"]},
]},
{phase:"D",tasks:[
{id:"e-d1",text:"Gate-in teyidi",textEn:"Gate-in confirmed",type:"semi",slaRef:"cyCutoff",slaOffset:0,slaUnit:"h",criteria:"Gate-in + container",criteriaEn:"Gate-in + container",owner:"ops",evReq:true,dependsOn:["e-b2"]},
{id:"e-d2",text:"On board / Sailed",textEn:"On board / Sailed",type:"manual",slaRef:"etd",slaOffset:0,slaUnit:"d",criteria:"Status + timestamp",criteriaEn:"Status + timestamp",owner:"ops",evReq:true,dependsOn:["e-d1"]},
]},
{phase:"E",tasks:[
{id:"e-e1",text:"Final BL yayınlandı",textEn:"Final BL issued",type:"auto",slaRef:"etd",slaOffset:2,slaUnit:"d",criteria:"Final BL yüklendi",criteriaEn:"Final BL uploaded",owner:"docs",evReq:false,dependsOn:["e-d2"],autoRule:"finalBLUploaded"},
{id:"e-e2",text:"Müşteri faturası",textEn:"Customer invoice",type:"semi",slaRef:"etd",slaOffset:2,slaUnit:"d",criteria:"AR invoice",criteriaEn:"AR invoice",owner:"finance",evReq:true,dependsOn:["e-d2"]},
{id:"e-e3",text:"Vendor faturaları",textEn:"Vendor invoices",type:"semi",slaRef:"etd",slaOffset:7,slaUnit:"d",criteria:"Actual costs",criteriaEn:"Actual costs",owner:"finance",evReq:false},
{id:"e-e4",text:"Tahsilat alındı",textEn:"AR paid",type:"auto",slaRef:"dueDate",slaOffset:0,slaUnit:"d",criteria:"PaidDate",criteriaEn:"PaidDate",owner:"finance",evReq:false,autoRule:"arPaid"},
]}];
const IM_TPL=[
{phase:"A",tasks:[
{id:"i-a1",text:"Pre-alert alındı",textEn:"Pre-alert received",type:"semi",slaRef:"eta",slaOffset:-7,slaUnit:"d",criteria:"MBL/HBL",criteriaEn:"MBL/HBL",owner:"ops",evReq:false},
{id:"i-a2",text:"Taraflar doğrulandı",textEn:"Parties verified",type:"semi",slaRef:"eta",slaOffset:-5,slaUnit:"d",criteria:"Consignee",criteriaEn:"Consignee",owner:"ops",evReq:false},
{id:"i-a3",text:"Charges pre-check",textEn:"Charges pre-check",type:"semi",slaRef:"eta",slaOffset:-5,slaUnit:"d",criteria:"Est charges",criteriaEn:"Est charges",owner:"finance",evReq:true},
]},
{phase:"B",tasks:[
{id:"i-b1",text:"Arrival notice",textEn:"Arrival notice",type:"semi",slaRef:"eta",slaOffset:-1,slaUnit:"d",criteria:"Notice + ETA",criteriaEn:"Notice + ETA",owner:"ops",evReq:false},
{id:"i-b2",text:"DO/Release başlatıldı",textEn:"DO/Release started",type:"manual",slaRef:"eta",slaOffset:0,slaUnit:"d",criteria:"DO request",criteriaEn:"DO request",owner:"ops",evReq:true,dependsOn:["i-b1"]},
{id:"i-b3",text:"DO alındı",textEn:"DO received",type:"auto",slaRef:"eta",slaOffset:2,slaUnit:"d",criteria:"DO yüklendi",criteriaEn:"DO uploaded",owner:"ops",evReq:false,dependsOn:["i-b2"],autoRule:"doUploaded"},
]},
{phase:"C",tasks:[
{id:"i-c1",text:"Gümrük dokümanları",textEn:"Customs docs",type:"semi",slaRef:"eta",slaOffset:2,slaUnit:"d",criteria:"Checklist",criteriaEn:"Checklist",owner:"customs",evReq:true,dependsOn:["i-b3"]},
{id:"i-c2",text:"Gümrük çekim",textEn:"Customs cleared",type:"semi",slaRef:"eta",slaOffset:3,slaUnit:"d",criteria:"Clearance",criteriaEn:"Clearance",owner:"customs",evReq:true,dependsOn:["i-c1"]},
{id:"i-c3",text:"Trucking ayarlandı",textEn:"Trucking arranged",type:"semi",slaRef:"eta",slaOffset:3,slaUnit:"d",criteria:"Vendor + tarih",criteriaEn:"Vendor + date",owner:"ops",evReq:true,dependsOn:["i-c2"]},
{id:"i-c4",text:"POD alındı",textEn:"POD received",type:"auto",slaRef:"eta",slaOffset:4,slaUnit:"d",criteria:"POD yüklendi",criteriaEn:"POD uploaded",owner:"ops",evReq:false,dependsOn:["i-c3"],autoRule:"podUploaded"},
]},
{phase:"D",tasks:[
{id:"i-d1",text:"Free-time tracker",textEn:"Free-time tracker",type:"semi",slaRef:"eta",slaOffset:0,slaUnit:"d",criteria:"Free time",criteriaEn:"Free time",owner:"ops",evReq:true},
{id:"i-d2",text:"D&D risk",textEn:"D&D risk",type:"auto",slaRef:"lastFreeDay",slaOffset:-2,slaUnit:"d",criteria:"Risk badge",criteriaEn:"Risk badge",owner:"system",evReq:false,dependsOn:["i-d1"],autoRule:"ddRisk"},
]},
{phase:"E",tasks:[
{id:"i-e1",text:"Müşteri faturası",textEn:"Customer invoice",type:"semi",slaRef:"delivery",slaOffset:2,slaUnit:"d",criteria:"AR invoice",criteriaEn:"AR invoice",owner:"finance",evReq:true},
{id:"i-e2",text:"Vendor faturaları",textEn:"Vendor invoices",type:"semi",slaRef:"delivery",slaOffset:7,slaUnit:"d",criteria:"Actual costs",criteriaEn:"Actual costs",owner:"finance",evReq:false},
{id:"i-e3",text:"Tahsilat alındı",textEn:"AR paid",type:"auto",slaRef:"dueDate",slaOffset:0,slaUnit:"d",criteria:"PaidDate",criteriaEn:"PaidDate",owner:"finance",evReq:false,autoRule:"arPaid"},
]}];
const PH_L={export:{tr:["phaseA","phaseB","phaseC","phaseD","phaseE"],en:["phaseA","phaseB","phaseC","phaseD","phaseE"]},import:{tr:["phaseA_imp","phaseB_imp","phaseC_imp","phaseD_imp","phaseE_imp"],en:["phaseA_imp","phaseB_imp","phaseC_imp","phaseD_imp","phaseE_imp"]}};
const PH_IC=["📋","🚛","📄","🏗️","💰"];
const TC=(th)=>({auto:th.cyan,semi:th.accent,manual:th.purple});
const OPS=["Deniz D.","Ayşe K.","Murat T.","Zeynep B."];
const ASN={"FF-2026-0042":{ops:"Deniz D.",sales:"Deniz D.",docs:"Ayşe K.",finance:"Zeynep B."},"FF-2026-0041":{ops:"Ayşe K.",finance:"Zeynep B.",customs:"Murat T."},"FF-2026-0040":{ops:"Deniz D.",sales:"Deniz D.",docs:"Ayşe K.",finance:"Zeynep B."},"FF-2026-0039":{ops:"Murat T.",docs:"Zeynep B.",finance:"Zeynep B.",sales:"Murat T."}};
const DOC_IC={hbl:"📋",mbl:"📜",packing:"📦",invoice:"🧾",vgm:"⚖️",booking_conf:"📌",cmr:"🚛",si:"📝",do_doc:"🔑",pod:"✅",draft_bl:"📄",final_bl:"📜",other:"📄"};
const REQ_D={export:["si","vgm","draft_bl","final_bl","hbl","packing","invoice"],import:["mbl","hbl","do_doc","pod","packing","invoice"]};
const getReqDocs=(b)=>REQ_D[b.templateType]||REQ_D.export;

/* SLA ENGINE */
function calcSlaDate(b,task){try{
  let base=null;const s=b.schedule||{};const c=b.cutoffs||{};const eq=b.equipment||{};
  if(task.slaRef==="booking")base=b.bookingDate;
  else if(task.slaRef==="etd")base=s.etdActual||s.etdPlanned;
  else if(task.slaRef==="eta")base=s.etaActual||s.etaPlanned;
  else if(task.slaRef==="delivery")base=s.etaActual||s.etaPlanned;
  else if(task.slaRef==="dueDate")base=b.arDueDate||s.etaPlanned;
  else if(task.slaRef==="lastFreeDay")base=b.lastFreeDay||s.etaActual||s.etaPlanned;
  else if(task.slaRef==="siCutoff")base=c.si;
  else if(task.slaRef==="vgmCutoff")base=c.vgm;
  else if(task.slaRef==="cyCutoff")base=c.cy;
  else if(task.slaRef==="emptyEarliest")base=eq.emptyEarliest;
  if(!base)return null;
  const isDT=base.length>10;const d=isDT?new Date(base.replace(" ","T")):new Date(base+"T00:00:00");
  if(isNaN(d.getTime()))return null;
  if(task.slaUnit==="d")d.setDate(d.getDate()+(task.slaOffset||0));
  else if(task.slaUnit==="h")d.setHours(d.getHours()+(task.slaOffset||0));
  return(task.slaUnit==="h"||isDT)?ymdhm(d):ymd(d);
}catch(e){return null;}}

const genTasks=(tpl,bid,ov={})=>{const am=ASN[bid]||{};return tpl.flatMap(ph=>ph.tasks.map(t=>({...t,phaseKey:ph.phase,assignee:t.owner==="system"?"Sistem":(am[t.owner]||"Deniz D."),done:ov[t.id]?.done||false,completedBy:ov[t.id]?.completedBy||null,completedAt:ov[t.id]?.completedAt||null,evidenceNote:ov[t.id]?.evidenceNote||null})));};

/* AUTO RULES */
const AUTO_R={fileCreated:(b)=>!!b.bookingDate,draftBLUploaded:(b)=>b.documents?.some(d=>d.type==="draft_bl"),finalBLUploaded:(b)=>b.documents?.some(d=>d.type==="final_bl"),doUploaded:(b)=>b.documents?.some(d=>d.type==="do_doc"),podUploaded:(b)=>b.documents?.some(d=>d.type==="pod"),arPaid:(b)=>!!b.arPaidDate||((b.charges||[]).filter(c=>c.bs==="sell").length>0&&(b.charges||[]).filter(c=>c.bs==="sell").every(c=>c.status==="paid")),ddRisk:(b)=>!!b.lastFreeDay&&todayStr()>=((dt)=>{const d=new Date(dt+"T00:00:00");d.setDate(d.getDate()-2);return ymd(d);})(b.lastFreeDay)};
function applyAutoRules(b,opts={}){const now=localNow();let changed=false;const tasks=(b.workflowTasks||[]).map(tk=>{if(tk.type!=="auto"||tk.done)return tk;if(tk.dependsOn?.length&&tk.dependsOn.some(id=>!(b.workflowTasks||[]).find(t=>t.id===id)?.done))return tk;const fn=tk.autoRule&&AUTO_R[tk.autoRule];if(!fn||!fn(b))return tk;changed=true;return{...tk,done:true,completedBy:"Sistem",completedAt:now,evidenceNote:"Otomatik"};});if(!changed)return b;if(opts.dryRun)return{...b,workflowTasks:tasks};const prev=new Map((b.workflowTasks||[]).map(t=>[t.id,t.done]));const na=tasks.filter(t=>t.done&&!prev.get(t.id)).map(tk=>({who:"Sistem",what:`${tk.text} — otomatik tamamlandı`,when:now,category:"task"}));return{...b,workflowTasks:tasks,auditLog:[...na,...(b.auditLog||[])]};}

/* VALIDATORS */
const VALIDATORS={"e-d1":(b)=>{const m=[];if(b.containers?.some(c=>c.number==="TBD"))m.push("Container no TBD");if(!(b.equipment||{}).gateInActual)m.push("Gate-in zamanı yok");return m;},"i-d1":(b)=>{const m=[];if(!b.lastFreeDay)m.push("Last free day yok");return m;},"e-e2":(b)=>{const m=[];if(!b.arDueDate)m.push("AR due date yok");return m;},"e-c2":(b)=>{const m=[];if(b.containers?.some(c=>!c.vgm))m.push("VGM eksik");return m;}};

/* OPERATIONAL EVENTS ENGINE */
function applyOperationalEvent(b,ev,opts={}){
  const s={...(b.schedule||{})};const c={...(b.cutoffs||{})};const eq={...(b.equipment||{})};let fl={...(b.flags||{})};
  const p=ev.payload||{};
  if(ev.type==="ROLLED"){if(p.newETD)s.etdPlanned=p.newETD;if(p.newVessel)s.vessel=p.newVessel;if(p.newVoyage)s.voyage=p.newVoyage;if(p.siCutoff)c.si=p.siCutoff;if(p.vgmCutoff)c.vgm=p.vgmCutoff;if(p.cyCutoff)c.cy=p.cyCutoff;fl.rolled=true;}
  else if(ev.type==="ETD_CHANGED"){if(p.newETD)s.etdPlanned=p.newETD;}
  else if(ev.type==="ETA_CHANGED"){if(p.newETA)s.etaPlanned=p.newETA;}
  else if(ev.type==="CUTOFF_UPDATED"){if(p.siCutoff)c.si=p.siCutoff;if(p.vgmCutoff)c.vgm=p.vgmCutoff;if(p.cyCutoff)c.cy=p.cyCutoff;}
  else if(ev.type==="EQUIPMENT_DELAY"){if(p.emptyEarliest)eq.emptyEarliest=p.emptyEarliest;}
  return recomputeWorkflow({...b,schedule:s,cutoffs:c,equipment:eq,flags:fl},opts);
}
function recomputeWorkflow(b,opts={}){return applyAutoRules(b,opts);}

function simulateReplan(b,draftEv){try{
  const oldT=(b.workflowTasks||[]).filter(tk=>!tk.done).map(tk=>({id:tk.id,text:tk.text,oldSla:calcSlaDate(b,tk)}));
  const sim=applyOperationalEvent({...b},{...draftEv},{dryRun:true});
  return oldT.map(o=>{const nt=(sim.workflowTasks||[]).find(tk=>tk.id===o.id);const ns=nt?calcSlaDate(sim,nt):null;return{...o,newSla:ns,changed:o.oldSla!==ns};}).filter(x=>x.changed);
}catch(e){return[];}}

/* FORWARDER EXCEPTIONS */
function deriveExceptions(b,lang){
  const t=L[lang];const ex=[];const c=b.cutoffs||{};const eq=b.equipment||{};const tasks=b.workflowTasks||[];
  const nd=(id)=>!tasks.find(tk=>tk.id===id)?.done;
  if(c.si&&safeHoursUntil(c.si)<24&&nd("e-c1"))ex.push({severity:"critical",label:t.siCutoffNear,section:"workflow",bookingId:b.id});
  if(c.vgm&&safeHoursUntil(c.vgm)<24&&nd("e-c2"))ex.push({severity:"critical",label:t.vgmCutoffNear,section:"workflow",bookingId:b.id});
  if(c.cy&&safeHoursUntil(c.cy)<24&&nd("e-d1"))ex.push({severity:"critical",label:t.cyCutoffNear,section:"workflow",bookingId:b.id});
  if(eq.emptyEarliest&&isBeforeToday(eq.emptyEarliest)&&nd("e-b1"))ex.push({severity:"warn",label:t.emptyOverdue,section:"workflow",bookingId:b.id});
  const etd=(b.schedule||{}).etdPlanned;
  if(etd&&safeHoursUntil(etd)<48&&nd("e-d2"))ex.push({severity:"warn",label:t.etdNear,section:"workflow",bookingId:b.id});
  return ex;
}

/* STORY TIMELINE */
function buildStory(b,lang){
  const items=[];
  (b.events||[]).forEach(ev=>{items.push({when:ev.when,who:ev.who,icon:"⚡",text:`${(EVENT_LBL[lang]||EVENT_LBL.en)[ev.type]||ev.type}: ${ev.summary||""}`,category:"schedule",source:ev.source});});
  (b.auditLog||[]).forEach(a=>{const cat=a.category||(a.what?.includes("tamamlandı")||a.what?.includes("geri")?"task":a.what?.includes("yüklen")?"docs":"task");items.push({when:a.when,who:a.who,icon:cat==="task"?"✓":cat==="docs"?"📄":cat==="finance"?"💰":"📋",text:a.what||"",category:cat,evidence:a.evidence});});
  return items.sort((a,b_)=>(b_.when||"").localeCompare(a.when||""));
}

/* COMPUTED */
const getBuy=(b)=>(b.charges||[]).filter(c=>c.bs==="buy").reduce((s,c)=>s+val(c.actual,c.est,0),0);
const getSell=(b)=>(b.charges||[]).filter(c=>c.bs==="sell").reduce((s,c)=>s+val(c.actual,c.est,0),0);
const getWfProg=(b)=>{const t=b.workflowTasks||[];const d=t.filter(x=>x.done).length;return{done:d,total:t.length,pct:t.length?Math.round(d/t.length*100):0};};
const getODTasks=(b)=>(b.workflowTasks||[]).filter(tk=>!tk.done&&isSlaOverdue(calcSlaDate(b,tk)));
const isBlocked=(tk,all)=>{if(!tk.dependsOn?.length)return false;return tk.dependsOn.some(id=>!all.find(t=>t.id===id)?.done);};
const getBlockerNames=(tk,all,lang)=>tk.dependsOn?.filter(id=>!all.find(t=>t.id===id)?.done).map(id=>{const t=all.find(x=>x.id===id);return t?(lang==="tr"?t.text:t.textEn):id;})||[];
const getNextAction=(b,cu)=>{const tasks=(b.workflowTasks||[]).filter(tk=>!tk.done&&!isBlocked(tk,b.workflowTasks||[])&&tk.type!=="auto");const od=tasks.filter(tk=>isSlaOverdue(calcSlaDate(b,tk)));const mine=tasks.filter(tk=>tk.assignee===cu);const pool=od.length?od:mine.length?mine:tasks;return pool.sort((a,b_)=>slaToMs(calcSlaDate(b,a))-slaToMs(calcSlaDate(b,b_)))[0]||null;};
const getMissing=(b)=>{const m=[];const s=b.schedule||{};if(!s.vessel)m.push({key:"vessel_missing",section:"datesVessel"});if(!s.etaPlanned&&!s.etaActual)m.push({key:"eta_missing",section:"datesVessel"});if(b.containers?.some(c=>!c.vgm))m.push({key:"vgm_missing",section:"containers"});if(!b.documents?.length)m.push({key:"docs_missing",section:"documents"});if(!b.consignee)m.push({key:"consignee_missing",section:"general"});return m;};
const getMissingReqDocs=(b)=>getReqDocs(b).filter(rd=>!b.documents?.some(d=>d.type===rd));
const etaSlipDays=(b)=>{try{const s=b.schedule||{};return daysDiff(s.etaActual,s.etaPlanned);}catch(e){return null;}};
const statusKey={quote:"quote",confirmed:"confirmed",loading:"loading",transit:"inTransit",arrived:"arrived",delivered:"delivered"};
const dirCfg=(d,th)=>({export:{c:th.accent,tr:"İHR",en:"EXP"},import:{c:th.warning,tr:"İTH",en:"IMP"},transit:{c:th.purple,tr:"TRN",en:"TRN"},crossTrade:{c:th.pink||th.purple,tr:"CT",en:"CT"}}[d]||{c:th.accent,tr:"?",en:"?"});
const stCfg=(s,th)=>({quote:{c:th.textMuted,bg:th.surface},confirmed:{c:th.accent,bg:th.accentBg},loading:{c:th.warning,bg:th.warningBg},transit:{c:th.cyan,bg:th.cyanBg},arrived:{c:th.purple,bg:th.purpleBg},delivered:{c:th.success,bg:th.successBg}}[s]||{c:th.textMuted,bg:th.surface});
const chSt=(s,th,lang)=>({estimated:{c:th.textMuted,l:lang==="tr"?"Tah":"Est"},pending:{c:th.warning,l:lang==="tr"?"Bkl":"Pend"},invoiced:{c:th.accent,l:lang==="tr"?"Ftrl":"Inv"},paid:{c:th.success,l:lang==="tr"?"Ödn":"Paid"}}[s]||{c:th.textMuted,l:s||"?"});

/* DRAFT BL HELPERS */
const DRAFT_BL_REQUIRED_FIELDS=[
  {key:"shipper",label:"Shipper",section:"general"},
  {key:"consignee",label:"Consignee",section:"general"},
  {key:"pol",label:"POL (Port of Loading)",section:"general"},
  {key:"pod",label:"POD (Port of Discharge)",section:"general"},
  {key:"vessel",label:"Vessel",section:"datesVessel"},
  {key:"voyage",label:"Voyage No",section:"datesVessel"},
  {key:"etd",label:"ETD",section:"datesVessel"},
  {key:"containerNo",label:"Container No",section:"containers"},
  {key:"sealNo",label:"Seal No",section:"containers"},
  {key:"packageQty",label:"Package Qty",section:"containers"},
  {key:"packageType",label:"Package Type",section:"containers"},
  {key:"grossWeight",label:"Gross Weight",section:"containers"},
  {key:"cbm",label:"CBM / Measurement",section:"containers"},
  {key:"placeOfIssue",label:"Place of Issue",section:"bl"},
  {key:"issueDate",label:"Issue Date",section:"bl"},
];

function getDraftBlData(b){
  const s=b.schedule||{};
  const cn=b.containers||[];
  const fc=b.charges?.find(c=>c.bs==="sell")||{};
  return{
    shipper:b.shipper||b.customer||"",
    consignee:b.consignee||"",
    notify:b.agent||"",
    vessel:s.vessel||"",
    voyage:s.voyage||"",
    etd:s.etdActual||s.etdPlanned||"",
    eta:s.etaActual||s.etaPlanned||"",
    pol:b.origin||"",
    pod:b.destination||"",
    freightTerms:b.incoterm||"",
    issueDate:b.blDraftFields?.issueDate||todayStr(),
    issuePlace:b.blDraftFields?.issuePlace||"",
    originalsCount:b.blDraftFields?.originalsCount||"3",
    freightPayableAt:b.blDraftFields?.freightPayableAt||"",
    commodity:b.commodity||"",
    containerRows:cn.map(c=>({
      number:c.number||"",
      type:c.type||"",
      seal:c.seal||"",
      weight:c.weight||"",
      cbm:c.cbm||"",
      packageQty:c.packageQty||"",
      packageType:c.packageType||"",
      description:c.description||b.commodity||"",
    })),
  };
}

function getDraftBlMissingFields(b){
  const s=b.schedule||{};
  const cn=b.containers||[];
  const bf=b.blDraftFields||{};
  const missing=[];
  if(!b.shipper&&!b.customer)missing.push(DRAFT_BL_REQUIRED_FIELDS.find(f=>f.key==="shipper"));
  if(!b.consignee)missing.push(DRAFT_BL_REQUIRED_FIELDS.find(f=>f.key==="consignee"));
  if(!b.origin)missing.push(DRAFT_BL_REQUIRED_FIELDS.find(f=>f.key==="pol"));
  if(!b.destination)missing.push(DRAFT_BL_REQUIRED_FIELDS.find(f=>f.key==="pod"));
  if(!s.vessel)missing.push(DRAFT_BL_REQUIRED_FIELDS.find(f=>f.key==="vessel"));
  if(!s.voyage)missing.push(DRAFT_BL_REQUIRED_FIELDS.find(f=>f.key==="voyage"));
  if(!s.etdPlanned&&!s.etdActual)missing.push(DRAFT_BL_REQUIRED_FIELDS.find(f=>f.key==="etd"));
  if(!cn.length||cn.every(c=>!c.number||c.number==="TBD"))missing.push(DRAFT_BL_REQUIRED_FIELDS.find(f=>f.key==="containerNo"));
  if(!cn.length||cn.every(c=>!c.seal))missing.push(DRAFT_BL_REQUIRED_FIELDS.find(f=>f.key==="sealNo"));
  if(!cn.length||cn.every(c=>!c.packageQty))missing.push(DRAFT_BL_REQUIRED_FIELDS.find(f=>f.key==="packageQty"));
  if(!cn.length||cn.every(c=>!c.packageType))missing.push(DRAFT_BL_REQUIRED_FIELDS.find(f=>f.key==="packageType"));
  if(!cn.length||cn.every(c=>!c.weight))missing.push(DRAFT_BL_REQUIRED_FIELDS.find(f=>f.key==="grossWeight"));
  if(!cn.length||cn.every(c=>!c.cbm))missing.push(DRAFT_BL_REQUIRED_FIELDS.find(f=>f.key==="cbm"));
  if(!bf.issuePlace)missing.push(DRAFT_BL_REQUIRED_FIELDS.find(f=>f.key==="placeOfIssue"));
  if(!bf.issueDate)missing.push(DRAFT_BL_REQUIRED_FIELDS.find(f=>f.key==="issueDate"));
  return missing.filter(Boolean);
}

function generateDraftBlHtml(data){
  const rows=data.containerRows.map(r=>`
    <tr>
      <td>${r.number||"—"}</td>
      <td>${r.seal||"—"}</td>
      <td>${r.type||"—"}</td>
      <td>${r.packageQty||"—"} ${r.packageType||""}</td>
      <td>${r.weight||"—"}</td>
      <td>${r.cbm||"—"}</td>
      <td>${r.description||"—"}</td>
    </tr>`).join("");
  return `<!DOCTYPE html>
<html><head><meta charset="UTF-8"/>
<style>
  body{font-family:Arial,sans-serif;font-size:11px;margin:20px;color:#1a2332;}
  h2{text-align:center;font-size:15px;letter-spacing:2px;margin-bottom:4px;}
  .subtitle{text-align:center;color:#666;font-size:10px;margin-bottom:16px;}
  .grid2{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px;}
  .box{border:1px solid #dde1e8;border-radius:4px;padding:8px;}
  .box-title{font-size:8px;font-weight:700;text-transform:uppercase;color:#7a8599;margin-bottom:4px;letter-spacing:.05em;}
  .box-val{font-size:11px;font-weight:600;color:#1a2332;}
  table{width:100%;border-collapse:collapse;margin-top:10px;font-size:10px;}
  th{background:#f3f5f8;padding:5px 4px;text-align:left;font-size:8.5px;text-transform:uppercase;color:#7a8599;border-bottom:2px solid #dde1e8;}
  td{padding:4px;border-bottom:1px solid #e5e8ed;}
  .footer{margin-top:14px;display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;}
  .stamp{border:2px solid #2563eb;border-radius:4px;padding:8px;text-align:center;}
  .stamp-label{font-size:8px;color:#7a8599;text-transform:uppercase;}
  .stamp-val{font-size:11px;font-weight:700;color:#2563eb;}
  .watermark{text-align:center;margin-top:12px;font-size:9px;color:#aaa;letter-spacing:3px;text-transform:uppercase;}
</style></head><body>
<h2>BILL OF LADING — DRAFT</h2>
<div class="subtitle">FOR APPROVAL ONLY — NOT NEGOTIABLE</div>
<div class="grid2">
  <div class="box"><div class="box-title">Shipper / Exporter</div><div class="box-val">${data.shipper||"—"}</div></div>
  <div class="box"><div class="box-title">Consignee</div><div class="box-val">${data.consignee||"—"}</div></div>
  <div class="box"><div class="box-title">Notify Party</div><div class="box-val">${data.notify||"—"}</div></div>
  <div class="box"><div class="box-title">Freight Terms / Incoterm</div><div class="box-val">${data.freightTerms||"—"}</div></div>
</div>
<div class="grid2">
  <div class="box"><div class="box-title">Port of Loading (POL)</div><div class="box-val">${data.pol||"—"}</div></div>
  <div class="box"><div class="box-title">Port of Discharge (POD)</div><div class="box-val">${data.pod||"—"}</div></div>
  <div class="box"><div class="box-title">Vessel</div><div class="box-val">${data.vessel||"—"}</div></div>
  <div class="box"><div class="box-title">Voyage No</div><div class="box-val">${data.voyage||"—"}</div></div>
  <div class="box"><div class="box-title">ETD</div><div class="box-val">${data.etd||"—"}</div></div>
  <div class="box"><div class="box-title">ETA</div><div class="box-val">${data.eta||"—"}</div></div>
</div>
<table>
  <thead><tr><th>Container No</th><th>Seal No</th><th>Type</th><th>Packages</th><th>Gross Weight</th><th>CBM</th><th>Description</th></tr></thead>
  <tbody>${rows||"<tr><td colspan='7' style='text-align:center;color:#aaa'>No container data</td></tr>"}</tbody>
</table>
<div class="footer">
  <div class="stamp"><div class="stamp-label">Place of Issue</div><div class="stamp-val">${data.issuePlace||"—"}</div></div>
  <div class="stamp"><div class="stamp-label">Issue Date</div><div class="stamp-val">${data.issueDate||"—"}</div></div>
  <div class="stamp"><div class="stamp-label">No. of Originals</div><div class="stamp-val">${data.originalsCount||"3"}</div></div>
</div>
<div class="watermark">DRAFT — NOT FOR RELEASE</div>
</body></html>`;
}

function saveDraftBlDocument(b,html,cu){
  const now=localNow();
  const docName=`Draft_BL_${b.id}`;
  const nd={name:docName,type:"draft_bl",date:todayStr(),status:"draft",size:"—",htmlContent:html};
  const updatedTasks=(b.workflowTasks||[]).map(tk=>
    tk.id==="e-c3"&&!tk.done
      ?{...tk,done:true,completedBy:cu||"Sistem",completedAt:now,evidenceNote:"Draft BL otomatik oluşturuldu"}
      :tk
  );
  return{
    ...b,
    documents:[...(b.documents||[]),nd],
    workflowTasks:updatedTasks,
    auditLog:[
      {who:cu||"Sistem",what:`Draft BL oluşturuldu — ${docName}`,when:now,category:"docs"},
      {who:cu||"Sistem",what:"Draft BL saved",when:now,category:"docs"},
      ...(b.auditLog||[])
    ]
  };
}

/* MOCK DATA */
const WF_OV={"FF-2026-0042":{"e-a1":{done:true,completedBy:"Deniz D.",completedAt:"2026-03-12 10:00"},"e-a2":{done:true,completedBy:"Deniz D.",completedAt:"2026-03-12 11:30"},"e-a3":{done:true,completedBy:"Deniz D.",completedAt:"2026-03-12 14:00"},"e-a4":{done:true,completedBy:"Deniz D.",completedAt:"2026-03-13 09:00",evidenceNote:"MAEU12345"},"e-b1":{done:true,completedBy:"Deniz D.",completedAt:"2026-03-13 10:30"},"e-b2":{done:true,completedBy:"Deniz D.",completedAt:"2026-03-13 14:00",evidenceNote:"Aras 14/03"},"e-c1":{done:true,completedBy:"Ayşe K.",completedAt:"2026-03-13 16:00"},"e-c2":{done:true,completedBy:"Deniz D.",completedAt:"2026-03-14 10:00"},"e-c3":{done:true,completedBy:"Ayşe K.",completedAt:"2026-03-14 11:00"},"e-c4":{done:true,completedBy:"Deniz D.",completedAt:"2026-03-14 15:00",evidenceNote:"Mail onay"},"e-d1":{done:true,completedBy:"Deniz D.",completedAt:"2026-03-15 07:30"},"e-d2":{done:true,completedBy:"Deniz D.",completedAt:"2026-03-16 18:00",evidenceNote:"1 gün rötarlı"}},"FF-2026-0041":{"i-a1":{done:true,completedBy:"Ayşe K.",completedAt:"2026-03-10 09:00"}},"FF-2026-0040":{"e-a1":{done:true,completedBy:"Deniz D.",completedAt:"2026-03-15 10:00"}},"FF-2026-0039":{"e-a1":{done:true,completedBy:"Murat T.",completedAt:"2026-02-25 09:00"},"e-a2":{done:true,completedBy:"Murat T.",completedAt:"2026-02-25 11:00"},"e-a3":{done:true,completedBy:"Murat T.",completedAt:"2026-02-25 14:00"},"e-a4":{done:true,completedBy:"Murat T.",completedAt:"2026-02-26 09:00"},"e-b1":{done:true,completedBy:"Murat T.",completedAt:"2026-02-26 10:00"},"e-b2":{done:true,completedBy:"Murat T.",completedAt:"2026-02-26 14:00"},"e-c1":{done:true,completedBy:"Zeynep B.",completedAt:"2026-02-27 09:00"},"e-c2":{done:true,completedBy:"Murat T.",completedAt:"2026-02-27 10:00"},"e-c3":{done:true,completedBy:"Zeynep B.",completedAt:"2026-02-27 14:00"},"e-c4":{done:true,completedBy:"Murat T.",completedAt:"2026-02-27 16:00"},"e-d1":{done:true,completedBy:"Murat T.",completedAt:"2026-02-28 07:00"},"e-d2":{done:true,completedBy:"Murat T.",completedAt:"2026-02-28 18:00"},"e-e1":{done:true,completedBy:"Zeynep B.",completedAt:"2026-03-01 10:00"}}};

const initBookings=()=>[
{id:"FF-2026-0042",customer:"Özkan Tekstil A.Ş.",agent:"Hamburg Forwarding GmbH",shipper:"Özkan Tekstil A.Ş.",consignee:"Meyer Textilien GmbH",direction:"export",mode:"fcl",incoterm:"FOB",commodity:"Tekstil",origin:"İstanbul (TRIST)",destination:"Hamburg (DEHAM)",status:"transit",bookingDate:"2026-03-12",arDueDate:"2026-04-15",schedule:{etdPlanned:"2026-03-15",etdActual:"2026-03-16",etaPlanned:"2026-04-02",etaActual:"2026-04-03",vessel:"VASSILIS A",voyage:"NAS04W26"},cutoffs:{si:"2026-03-12 18:00",vgm:"2026-03-13 23:59",cy:"2026-03-14 12:00"},equipment:{emptyEarliest:"2026-03-11",emptyPlanned:"2026-03-12",emptyActual:"2026-03-12",stuffingPlanned:"2026-03-13",gateInActual:"2026-03-15 07:30"},flags:{rolled:true},events:[{id:"ev1",when:"2026-03-15 14:00",who:"Deniz D.",type:"ROLLED",source:"carrier_notice",summary:"Maersk rol: MARTINE A → VASSILIS A, ETD 16/03",payload:{newETD:"2026-03-16",newVessel:"VASSILIS A",newVoyage:"NAS04W26"}}],containers:[{number:"TCLU1234567",type:"40'HC",weight:"18,200 kg",vgm:true,seal:"TR0098231",packageQty:"1,200",packageType:"CTNS",cbm:"62.5"},{number:"MSCU7654321",type:"40'HC",weight:"16,800 kg",vgm:true,seal:"TR0098232",packageQty:"980",packageType:"CTNS",cbm:"58.3"}],charges:[{type:"Ocean Freight",bs:"buy",vendor:"Maersk",amount:1800,ccy:"USD",est:1800,actual:1800,status:"invoiced",dueDate:"2026-04-15"},{type:"Ocean Freight",bs:"sell",vendor:"Özkan Tekstil",amount:2600,ccy:"USD",est:2600,actual:2600,status:"pending",dueDate:"2026-04-01"},{type:"THC",bs:"buy",vendor:"Kumport",amount:280,ccy:"USD",est:280,actual:280,status:"paid",paidDate:"2026-03-18"},{type:"THC",bs:"sell",vendor:"Özkan Tekstil",amount:350,ccy:"USD",est:350,actual:350,status:"pending"},{type:"Trucking",bs:"buy",vendor:"Aras",amount:270,ccy:"EUR",est:250,actual:270,status:"invoiced"},{type:"Trucking",bs:"sell",vendor:"Özkan Tekstil",amount:275,ccy:"USD",est:275,actual:275,status:"pending"}],documents:[{name:"HBL Draft",type:"hbl",date:"2026-03-14",status:"draft",size:"245 KB"},{name:"Packing List",type:"packing",date:"2026-03-12",status:"final",size:"128 KB"},{name:"Invoice",type:"invoice",date:"2026-03-12",status:"final",size:"96 KB"},{name:"VGM",type:"vgm",date:"2026-03-14",status:"final",size:"64 KB"}],trackingEvents:[{event:"loaded",location:"İstanbul",date:"2026-03-16",done:true},{event:"transshipment",location:"Pire",date:"2026-03-22",done:true},{event:"arrival",location:"Hamburg",date:"2026-04-03",done:false}],notes:[{user:"Deniz D.",date:"2026-03-16 09:15",text:"Gemi 1 gün rötarlı.",tag:"ops"}],workflowTasks:null,templateType:"export",auditLog:[{who:"Deniz D.",what:"Sailed tamamlandı",when:"2026-03-16 18:00",evidence:"1gün rötar",category:"task"},{who:"Ayşe K.",what:"Draft BL yüklendi",when:"2026-03-14 11:00",category:"docs"},{who:"Deniz D.",what:"Dosya oluşturuldu",when:"2026-03-12 10:00",category:"task"}]},
{id:"FF-2026-0041",customer:"Anadolu Kimya Ltd.",direction:"import",mode:"fcl",origin:"Shanghai (CNSHA)",destination:"Mersin (TRMER)",status:"loading",bookingDate:"2026-03-09",arDueDate:"2026-04-25",schedule:{etdPlanned:"2026-03-18",etaPlanned:"2026-04-10"},cutoffs:{},equipment:{},flags:{},events:[],containers:[{number:"CMAU9988776",type:"20'DC",weight:"12,500 kg",vgm:false}],charges:[{type:"Ocean Freight",bs:"buy",vendor:"MSC",amount:1500,ccy:"USD",est:1500,actual:1500,status:"pending"},{type:"Ocean Freight",bs:"sell",vendor:"Anadolu Kimya",amount:2100,ccy:"USD",est:2100,actual:2100,status:"pending"}],documents:[{name:"Booking Conf",type:"booking_conf",date:"2026-03-10",status:"final",size:"80 KB"}],trackingEvents:[],notes:[],workflowTasks:null,templateType:"import",auditLog:[{who:"Ayşe K.",what:"Pre-alert yüklendi",when:"2026-03-10 09:00",category:"docs"}]},
{id:"FF-2026-0040",customer:"Ege Otomotiv San.",direction:"export",mode:"lcl",origin:"İzmir (TRIZM)",destination:"Felixstowe (GBFXT)",status:"confirmed",bookingDate:"2026-03-14",schedule:{etdPlanned:"2026-03-20"},cutoffs:{si:"2026-03-18 18:00",vgm:"2026-03-19 12:00",cy:"2026-03-19 16:00"},equipment:{emptyEarliest:"2026-03-17"},flags:{},events:[],containers:[],charges:[{type:"LCL",bs:"buy",vendor:"CMA CGM",amount:500,ccy:"USD",est:500,status:"estimated"},{type:"LCL",bs:"sell",vendor:"Ege Otomotiv",amount:780,ccy:"USD",est:780,status:"estimated"}],documents:[],trackingEvents:[],notes:[],workflowTasks:null,templateType:"export",auditLog:[{who:"Deniz D.",what:"Dosya oluşturuldu",when:"2026-03-15 10:00",category:"task"}]},
{id:"FF-2026-0039",customer:"Balkan Trading d.o.o.",direction:"transit",mode:"fcl",origin:"Nhava Sheva (INNSA)",destination:"Constanta (ROCND)",status:"transit",bookingDate:"2026-02-25",arDueDate:"2026-04-10",schedule:{etdPlanned:"2026-02-28",etaPlanned:"2026-03-25",etaActual:"2026-03-28"},cutoffs:{},equipment:{},flags:{},events:[],containers:[{number:"EGLV3344556",type:"40'DC",weight:"22,000 kg",vgm:true}],charges:[{type:"Ocean Freight",bs:"buy",vendor:"Hapag-Lloyd",amount:900,ccy:"USD",est:900,actual:900,status:"invoiced"},{type:"Ocean Freight",bs:"sell",vendor:"Balkan Trading",amount:1350,ccy:"USD",est:1350,actual:1350,status:"pending",dueDate:"2026-03-15"}],documents:[{name:"MBL",type:"mbl",date:"2026-02-28",status:"final",size:"190 KB"}],trackingEvents:[{event:"loaded",location:"Nhava Sheva",date:"2026-02-28",done:true},{event:"arrival",location:"Constanta",date:"2026-03-28",done:false}],notes:[],workflowTasks:null,templateType:"export",auditLog:[{who:"Zeynep B.",what:"Final BL yüklendi",when:"2026-03-01 10:00",category:"docs"},{who:"Murat T.",what:"Dosya oluşturuldu",when:"2026-02-25 09:00",category:"task"}]}
];

/* UI COMPONENTS */
function PBar({pct,th,h=6}){return React.createElement("div",{style:{width:"100%",height:h,borderRadius:h/2,background:th.surface,overflow:"hidden"}},React.createElement("div",{style:{height:"100%",width:`${pct}%`,borderRadius:h/2,background:pct===100?th.success:th.accent,transition:"width .3s"}}));}
function IR({label,value,hl,th}){const d=value===null||value===undefined||value===""?"—":value;return(<div style={{display:"flex",justifyContent:"space-between",padding:"2px 0",borderBottom:`1px solid ${th.divider}`}}><span style={{color:th.textMuted,fontSize:10.5}}>{label}</span><span style={{color:hl||th.text,fontSize:10.5,fontWeight:hl?600:400}}>{d}</span></div>);}
function Section({id,title,icon,badge,th,defaultOpen=true,children,alert}){const[open,setOpen]=useState(defaultOpen);return(<div id={id} style={{borderBottom:`1px solid ${th.divider}`}}><button onClick={()=>setOpen(!open)} style={{width:"100%",display:"flex",alignItems:"center",justifyContent:"space-between",padding:"8px 12px",background:"none",border:"none",cursor:"pointer",color:th.text,fontFamily:"'DM Sans',sans-serif",fontSize:10,fontWeight:600,letterSpacing:".04em",textTransform:"uppercase"}}><span style={{display:"flex",alignItems:"center",gap:4}}><span style={{fontSize:10}}>{icon}</span>{title}{badge&&<span style={{background:th.accentSoft,color:th.accent,padding:"1px 4px",borderRadius:6,fontSize:8.5,fontWeight:600,textTransform:"none"}}>{badge}</span>}{alert&&<span style={{background:th.dangerBg,color:th.danger,padding:"1px 4px",borderRadius:6,fontSize:8.5,fontWeight:600,textTransform:"none"}}>{alert}</span>}</span><span style={{transform:open?"rotate(0)":"rotate(-90deg)",transition:"transform .2s",fontSize:7,color:th.textMuted}}>▼</span></button>{open&&<div style={{padding:"0 12px 8px"}}>{children}</div>}</div>);}

/* MODALS */
function EvidenceModal({task,lang,th,onSave,onClose,valErrs=[]}){const t=L[lang];const[note,setNote]=useState("");const isReq=task.evReq;const hasVE=valErrs.length>0;const ok=!hasVE&&(!isReq||note.trim());return(<div style={{position:"fixed",top:0,left:0,width:"100%",height:"100%",background:th.backdrop,zIndex:200,display:"flex",alignItems:"center",justifyContent:"center"}} onClick={onClose}><div onClick={e=>e.stopPropagation()} style={{background:th.cardBg,borderRadius:10,padding:16,width:340,border:`1px solid ${th.cardBorder}`,fontFamily:"'DM Sans',sans-serif"}}><div style={{fontSize:12.5,fontWeight:700,color:th.text,marginBottom:2}}>{t.markComplete}</div><div style={{fontSize:10.5,color:th.textSecondary,marginBottom:8}}>{lang==="tr"?task.text:task.textEn}</div>{hasVE&&<div style={{marginBottom:6,padding:"5px 7px",borderRadius:5,background:th.dangerBg}}><div style={{color:th.danger,fontSize:9.5,fontWeight:600}}>⚠ Eksik:</div>{valErrs.map((e,i)=><div key={i} style={{color:th.danger,fontSize:9.5}}>• {e}</div>)}</div>}<textarea value={note} onChange={e=>setNote(e.target.value)} placeholder={t.addEvidence} rows={2} style={{width:"100%",padding:"6px 8px",borderRadius:5,border:`1px solid ${th.inputBorder}`,background:th.inputBg,color:th.text,fontSize:11,fontFamily:"'DM Sans',sans-serif",resize:"vertical",outline:"none",boxSizing:"border-box"}}/><div style={{display:"flex",gap:4,justifyContent:"flex-end",marginTop:8}}><button onClick={onClose} style={{padding:"5px 10px",borderRadius:5,border:`1px solid ${th.cardBorder}`,background:"transparent",color:th.textSecondary,cursor:"pointer",fontSize:10.5,fontFamily:"'DM Sans',sans-serif"}}>{t.cancel}</button><button onClick={()=>{if(ok)onSave(note.trim()||null);}} style={{padding:"5px 10px",borderRadius:5,border:"none",background:ok?th.gradient:th.blocked,color:ok?th.gradientText:th.textMuted,cursor:ok?"pointer":"not-allowed",fontSize:10.5,fontWeight:600,fontFamily:"'DM Sans',sans-serif"}}>✓ {t.save}</button></div></div></div>);}

function ReassignModal({task,th,lang,onSave,onClose}){const t=L[lang];const[sel,setSel]=useState(task.assignee);return(<div style={{position:"fixed",top:0,left:0,width:"100%",height:"100%",background:th.backdrop,zIndex:200,display:"flex",alignItems:"center",justifyContent:"center"}} onClick={onClose}><div onClick={e=>e.stopPropagation()} style={{background:th.cardBg,borderRadius:10,padding:16,width:300,border:`1px solid ${th.cardBorder}`,fontFamily:"'DM Sans',sans-serif"}}><div style={{fontSize:12.5,fontWeight:700,color:th.text,marginBottom:6}}>{t.reassign}</div><select value={sel} onChange={e=>setSel(e.target.value)} style={{width:"100%",padding:"5px",borderRadius:5,border:`1px solid ${th.inputBorder}`,background:th.inputBg,color:th.text,fontSize:11,fontFamily:"'DM Sans',sans-serif",marginBottom:8}}>{OPS.map(op=><option key={op} value={op}>{op}</option>)}</select><div style={{display:"flex",gap:4,justifyContent:"flex-end"}}><button onClick={onClose} style={{padding:"5px 10px",borderRadius:5,border:`1px solid ${th.cardBorder}`,background:"transparent",color:th.textSecondary,cursor:"pointer",fontSize:10.5,fontFamily:"'DM Sans',sans-serif"}}>{t.cancel}</button><button onClick={()=>onSave(sel)} style={{padding:"5px 10px",borderRadius:5,border:"none",background:th.gradient,color:th.gradientText,cursor:"pointer",fontSize:10.5,fontWeight:600,fontFamily:"'DM Sans',sans-serif"}}>{t.reassignTo} {sel}</button></div></div></div>);}

function QuickUpdateModal({booking:b,lang,th,currentUser,onSave,onClose}){
  const t=L[lang];const[evT,setEvT]=useState("ROLLED");const[note,setNote]=useState("");const[src,setSrc]=useState("manual");
  const[nETD,setNETD]=useState("");const[nETA,setNETA]=useState("");const[nVes,setNVes]=useState("");const[nVoy,setNVoy]=useState("");
  const[siC,setSiC]=useState("");const[vgmC,setVgmC]=useState("");const[cyC,setCyC]=useState("");const[emE,setEmE]=useState("");
  const mkPayload=()=>{const p={};if(evT==="ROLLED"||evT==="ETD_CHANGED"){if(nETD)p.newETD=nETD;}if(evT==="ROLLED"){if(nVes)p.newVessel=nVes;if(nVoy)p.newVoyage=nVoy;}if(evT==="ROLLED"||evT==="CUTOFF_UPDATED"){if(siC)p.siCutoff=siC;if(vgmC)p.vgmCutoff=vgmC;if(cyC)p.cyCutoff=cyC;}if(evT==="ETA_CHANGED"){if(nETA)p.newETA=nETA;}if(evT==="EQUIPMENT_DELAY"){if(emE)p.emptyEarliest=emE;}return p;};
  const mkEv=()=>({id:uid(),when:localNow(),who:currentUser,type:evT,source:src,summary:note||`${(EVENT_LBL[lang]||EVENT_LBL.en)[evT]}`,payload:mkPayload()});
  const ok=()=>{if(evT==="ROLLED"&&!nETD)return false;if(evT==="ETD_CHANGED"&&!nETD)return false;if(evT==="ETA_CHANGED"&&!nETA)return false;if(evT==="CUTOFF_UPDATED"&&!siC&&!vgmC&&!cyC)return false;if(evT==="EQUIPMENT_DELAY"&&!emE)return false;return true;};
  const preview=ok()?simulateReplan(b,mkEv()):[];
  const inp={width:"100%",padding:"4px 6px",borderRadius:4,border:`1px solid ${th.inputBorder}`,background:th.inputBg,color:th.text,fontSize:10.5,fontFamily:"'DM Sans',sans-serif",boxSizing:"border-box"};
  const lbl={color:th.textMuted,fontSize:9.5,fontWeight:600,marginBottom:1,marginTop:5,display:"block"};
  return(<div style={{position:"fixed",top:0,left:0,width:"100%",height:"100%",background:th.backdrop,zIndex:200,display:"flex",alignItems:"center",justifyContent:"center"}} onClick={onClose}><div onClick={e=>e.stopPropagation()} style={{background:th.cardBg,borderRadius:10,padding:16,width:400,maxHeight:"80vh",overflowY:"auto",border:`1px solid ${th.cardBorder}`,fontFamily:"'DM Sans',sans-serif"}}>
    <div style={{fontSize:13,fontWeight:700,color:th.text,marginBottom:8}}>⚡ {t.quickUpdate} — {b.id}</div>
    <label style={lbl}>{t.eventType}</label>
    <select value={evT} onChange={e=>setEvT(e.target.value)} style={inp}>{EVENT_TYPES.map(et=><option key={et} value={et}>{(EVENT_LBL[lang]||EVENT_LBL.en)[et]}</option>)}</select>
    <label style={lbl}>{t.source}</label>
    <select value={src} onChange={e=>setSrc(e.target.value)} style={inp}><option value="manual">{t.manualSrc}</option><option value="carrier_notice">{t.carrierNotice}</option><option value="system">{t.systemSrc}</option></select>
    {(evT==="ROLLED"||evT==="ETD_CHANGED")&&<><label style={lbl}>{t.newETD} *</label><input type="date" value={nETD} onChange={e=>setNETD(e.target.value)} style={inp}/></>}
    {evT==="ROLLED"&&<><label style={lbl}>{t.newVessel}</label><input value={nVes} onChange={e=>setNVes(e.target.value)} style={inp}/><label style={lbl}>{t.newVoyage}</label><input value={nVoy} onChange={e=>setNVoy(e.target.value)} style={inp}/></>}
    {(evT==="ROLLED"||evT==="CUTOFF_UPDATED")&&<><label style={lbl}>{t.siCutoff}</label><input type="datetime-local" value={(siC||"").replace(" ","T")} onChange={e=>setSiC(e.target.value.replace("T"," "))} style={inp}/><label style={lbl}>{t.vgmCutoff}</label><input type="datetime-local" value={(vgmC||"").replace(" ","T")} onChange={e=>setVgmC(e.target.value.replace("T"," "))} style={inp}/><label style={lbl}>{t.cyCutoff}</label><input type="datetime-local" value={(cyC||"").replace(" ","T")} onChange={e=>setCyC(e.target.value.replace("T"," "))} style={inp}/></>}
    {evT==="ETA_CHANGED"&&<><label style={lbl}>{t.newETA} *</label><input type="date" value={nETA} onChange={e=>setNETA(e.target.value)} style={inp}/></>}
    {evT==="EQUIPMENT_DELAY"&&<><label style={lbl}>{t.emptyEarliest} *</label><input type="date" value={emE} onChange={e=>setEmE(e.target.value)} style={inp}/></>}
    <label style={lbl}>{t.note} {(evT==="ROLLED"||evT==="EQUIPMENT_DELAY")?"*":""}</label>
    <textarea value={note} onChange={e=>setNote(e.target.value)} rows={2} style={{...inp,resize:"vertical"}}/>
    {preview.length>0&&<div style={{marginTop:8,padding:"6px 8px",borderRadius:6,background:th.warningBg,border:`1px solid ${th.warning}20`}}><div style={{color:th.warning,fontSize:10,fontWeight:700,marginBottom:3}}>{t.impactPreview} ({preview.length} {t.tasksAffected})</div>{preview.slice(0,6).map((p,i)=><div key={i} style={{display:"flex",justifyContent:"space-between",padding:"1px 0",fontSize:9.5}}><span style={{color:th.text}}>{p.text}</span><span style={{color:th.textMuted}}>{fmtSla(p.oldSla)} → <span style={{color:th.warning,fontWeight:600}}>{fmtSla(p.newSla)}</span></span></div>)}</div>}
    {preview.length===0&&ok()&&<div style={{marginTop:6,color:th.success,fontSize:9.5}}>{t.noImpact}</div>}
    <div style={{display:"flex",gap:4,justifyContent:"flex-end",marginTop:10}}><button onClick={onClose} style={{padding:"5px 10px",borderRadius:5,border:`1px solid ${th.cardBorder}`,background:"transparent",color:th.textSecondary,cursor:"pointer",fontSize:10.5,fontFamily:"'DM Sans',sans-serif"}}>{t.cancel}</button><button onClick={()=>{if(ok())onSave(mkEv());}} style={{padding:"5px 10px",borderRadius:5,border:"none",background:ok()?th.gradient:th.blocked,color:ok()?th.gradientText:th.textMuted,cursor:ok()?"pointer":"not-allowed",fontSize:10.5,fontWeight:600,fontFamily:"'DM Sans',sans-serif"}}>⚡ {t.save}</button></div>
  </div></div>);
}

function DocDrawer({doc,th,t,onClose}){if(!doc)return null;return(<div style={{position:"fixed",top:0,right:0,width:360,height:"100vh",background:th.cardBg,borderLeft:`1px solid ${th.cardBorder}`,boxShadow:"-4px 0 24px rgba(0,0,0,.15)",zIndex:100,display:"flex",flexDirection:"column",fontFamily:"'DM Sans',sans-serif"}}><div style={{padding:"10px",borderBottom:`1px solid ${th.divider}`,display:"flex",justifyContent:"space-between",alignItems:"center"}}><div style={{display:"flex",alignItems:"center",gap:5}}><span style={{fontSize:16}}>{DOC_IC[doc.type]||"📄"}</span><div><div style={{color:th.text,fontSize:12,fontWeight:700}}>{doc.name}</div><div style={{color:th.textMuted,fontSize:9.5}}>{doc.date} · {doc.size||"—"}</div></div></div><button onClick={onClose} style={{background:th.surface,border:`1px solid ${th.cardBorder}`,borderRadius:5,color:th.text,padding:"3px 6px",cursor:"pointer",fontSize:9}}>✕</button></div><div style={{flex:1,display:"flex",alignItems:"center",justifyContent:"center",background:th.surface,margin:10,borderRadius:6}}><div style={{textAlign:"center",color:th.textMuted}}><div style={{fontSize:36}}>{DOC_IC[doc.type]||"📄"}</div><div style={{fontSize:11}}>{doc.name}</div></div></div><div style={{padding:"6px 10px",borderTop:`1px solid ${th.divider}`,display:"flex",gap:4}}><button style={{flex:1,padding:5,borderRadius:5,border:`1px solid ${th.cardBorder}`,background:th.surface,color:th.text,cursor:"pointer",fontSize:10,fontFamily:"'DM Sans',sans-serif"}}>⬇ {t.download}</button><button style={{flex:1,padding:5,borderRadius:5,border:"none",background:th.gradient,color:th.gradientText,cursor:"pointer",fontSize:10,fontWeight:600,fontFamily:"'DM Sans',sans-serif"}}>🔗 {t.share}</button></div></div>);}

function StoryPanel({items,auditLog,lang,th}){
  const t=L[lang];const[mode,setMode]=useState("story");const[catF,setCatF]=useState("all");const[whoF,setWhoF]=useState("");
  const cats=["all","schedule","docs","task","finance"];
  const filtered=mode==="story"?items.filter(i=>catF==="all"||i.category===catF).filter(i=>!whoF||i.who?.toLowerCase().includes(whoF.toLowerCase())):
    (auditLog||[]).filter(a=>catF==="all"||(a.category||"task")===catF).filter(a=>!whoF||a.who?.toLowerCase().includes(whoF.toLowerCase()));
  return(<div>
    <div style={{display:"flex",gap:0,borderBottom:`1px solid ${th.divider}`}}>{[{k:"story",l:t.storyMode,ic:"📖"},{k:"forensic",l:t.forensicMode,ic:"🔍"}].map(m=><button key={m.k} onClick={()=>setMode(m.k)} style={{flex:1,padding:"6px 0",border:"none",borderBottom:`2px solid ${mode===m.k?th.accent:"transparent"}`,background:"transparent",color:mode===m.k?th.accent:th.textSecondary,fontSize:10.5,fontWeight:600,cursor:"pointer",fontFamily:"'DM Sans',sans-serif"}}>{m.ic} {m.l}</button>)}</div>
    <div style={{display:"flex",gap:4,padding:"5px 10px",borderBottom:`1px solid ${th.divider}`,flexWrap:"wrap"}}>{cats.map(c=><button key={c} onClick={()=>setCatF(c)} style={{padding:"1px 6px",borderRadius:8,border:`1px solid ${catF===c?th.accent:th.cardBorder}`,background:catF===c?th.accentBg:"transparent",color:catF===c?th.accent:th.textMuted,fontSize:9,cursor:"pointer",fontFamily:"'DM Sans',sans-serif"}}>{c==="all"?t.allCategories:t[c+"Evt"]||c}</button>)}<input value={whoF} onChange={e=>setWhoF(e.target.value)} placeholder={t.filterWho} style={{marginLeft:"auto",padding:"2px 6px",borderRadius:4,border:`1px solid ${th.inputBorder}`,background:th.inputBg,color:th.text,fontSize:9.5,width:80,fontFamily:"'DM Sans',sans-serif"}}/></div>
    <div style={{maxHeight:300,overflowY:"auto"}}>{filtered.slice(0,40).map((item,i)=><div key={i} style={{display:"flex",gap:6,padding:"5px 10px",borderBottom:`1px solid ${th.divider}`,alignItems:"flex-start"}} onMouseEnter={e=>e.currentTarget.style.background=th.hover} onMouseLeave={e=>e.currentTarget.style.background="transparent"}><span style={{fontSize:10,width:16,flexShrink:0,textAlign:"center"}}>{item.icon||"•"}</span><div style={{flex:1}}><div style={{display:"flex",alignItems:"center",gap:4,flexWrap:"wrap"}}><span style={{color:th.text,fontSize:10.5,fontWeight:600}}>{item.who||"Sistem"}</span>{item.source&&<span style={{color:th.textMuted,fontSize:8.5,padding:"0 3px",borderRadius:3,background:th.surface}}>{item.source}</span>}</div><div style={{color:th.textSecondary,fontSize:10.5}}>{mode==="story"?item.text:(item.what||item.text)}</div>{item.evidence&&<div style={{color:th.cyan,fontSize:9.5}}>📎 {item.evidence}</div>}</div><span style={{color:th.textMuted,fontSize:9,fontFamily:"'Space Mono',monospace",whiteSpace:"nowrap",flexShrink:0}}>{item.when}</span></div>)}</div>
  </div>);
}

/* WORKFLOW TAB */
function WorkflowTab({booking:b,lang,th,onUpdate,cu,role}){
  const t=L[lang];const tasks=b.workflowTasks||[];const isExp=b.templateType==="export";
  const tpl=isExp?EX_TPL:IM_TPL;const pLb=PH_L[isExp?"export":"import"][lang];
  const prog=getWfProg(b);const tc=TC(th);const[evTk,setEvTk]=useState(null);
  const complete=(tid,evNote)=>{const now=localNow();const tkO=tasks.find(tk=>tk.id===tid);const behalf=role==="admin"&&tkO?.assignee!==cu;let u={...b,workflowTasks:tasks.map(tk=>tk.id===tid?{...tk,done:true,completedBy:cu,completedAt:now,evidenceNote:evNote}:tk),auditLog:[{who:cu,what:(lang==="tr"?tkO?.text:tkO?.textEn)+(behalf?` (${tkO.assignee} adına)`:" — tamamlandı"),when:now,evidence:evNote,category:"task"},...(b.auditLog||[])]};u=applyAutoRules(u);onUpdate(u);setEvTk(null);};
  const undo=(tid)=>{if(role!=="admin")return;const now=localNow();const tkO=tasks.find(tk=>tk.id===tid);onUpdate({...b,workflowTasks:tasks.map(tk=>tk.id===tid?{...tk,done:false,completedBy:null,completedAt:null,evidenceNote:null}:tk),auditLog:[{who:cu,what:(lang==="tr"?tkO?.text:tkO?.textEn)+" — geri alındı",when:now,category:"task"},...(b.auditLog||[])]});};
  const click=(tk)=>{if(tk.done){if(role==="admin")undo(tk.id);return;}if(tk.type==="auto"||isBlocked(tk,tasks))return;if(role==="operator"&&tk.assignee!==cu)return;setEvTk(tk);};
  const vE=evTk?(VALIDATORS[evTk.id]?.(b)||[]):[];
  return(<div>{evTk&&<EvidenceModal task={evTk} lang={lang} th={th} onSave={(n)=>complete(evTk.id,n)} onClose={()=>setEvTk(null)} valErrs={vE}/>}
  <div style={{padding:"8px 12px",borderBottom:`1px solid ${th.divider}`,background:th.cardBg}}><div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:4}}><span style={{color:th.text,fontSize:12,fontWeight:700}}>{isExp?"FCL Export":"FCL Import"} — {t.workflow}</span><span style={{color:prog.pct===100?th.success:th.accent,fontSize:12,fontWeight:700,fontFamily:"'Space Mono',monospace"}}>{prog.pct}%</span></div><PBar pct={prog.pct} th={th} h={6}/><div style={{display:"flex",gap:8,marginTop:4}}><span style={{color:th.textSecondary,fontSize:10}}>{prog.done}/{prog.total}</span>{getODTasks(b).length>0&&<span style={{color:th.danger,fontSize:10,fontWeight:600}}>⚠ {getODTasks(b).length} {t.taskOverdue}</span>}</div></div>
  <div style={{maxHeight:"calc(100vh - 240px)",overflowY:"auto"}}>{tpl.map((phase,pi)=>{const pT=tasks.filter(tk=>tk.phaseKey===phase.phase);const pD=pT.filter(tk=>tk.done).length;const hasOD=pT.some(tk=>!tk.done&&isSlaOverdue(calcSlaDate(b,tk)));
  return(<div key={phase.phase} style={{borderBottom:`1px solid ${th.divider}`}}><div style={{padding:"7px 12px",background:th.phaseBg[pi],display:"flex",alignItems:"center",justifyContent:"space-between"}}><div style={{display:"flex",alignItems:"center",gap:5}}><span style={{fontSize:11}}>{PH_IC[pi]}</span><span style={{color:th.text,fontSize:10.5,fontWeight:600}}>{t.phase} {phase.phase}: {t[pLb[pi]]}</span>{hasOD&&<span style={{color:th.danger,fontSize:8,padding:"1px 3px",borderRadius:5,background:th.dangerBg}}>⚠</span>}</div><span style={{color:pD===pT.length?th.success:th.textMuted,fontSize:9,fontFamily:"'Space Mono',monospace"}}>{pD}/{pT.length}</span></div>
  {pT.map(tk=>{const sla=calcSlaDate(b,tk);const isOD=!tk.done&&isSlaOverdue(sla);const bl=!tk.done&&isBlocked(tk,tasks);const isA=tk.type==="auto";const can=!isA&&!bl&&!tk.done;const tC=tc[tk.type]||th.textMuted;const tL=tk.type==="auto"?t.auto:tk.type==="semi"?t.semiAuto:t.manual;
  return(<div key={tk.id} style={{padding:"5px 12px 5px 34px",borderBottom:`1px solid ${th.divider}`,background:bl?`${th.blocked}30`:isOD?th.overdueBg:"transparent",display:"flex",alignItems:"flex-start",gap:7,opacity:bl?0.6:1}} onMouseEnter={e=>{if(!bl&&!isOD)e.currentTarget.style.background=th.hover;}} onMouseLeave={e=>{e.currentTarget.style.background=bl?`${th.blocked}30`:isOD?th.overdueBg:"transparent";}}>
    <div onClick={()=>{if(tk.done&&role==="admin"){undo(tk.id);return;}if(can)click(tk);}} style={{width:16,height:16,borderRadius:4,border:`2px solid ${tk.done?th.success:bl?th.blocked:isA?th.cyan:isOD?th.danger:th.accent}`,background:tk.done?th.success:"transparent",display:"flex",alignItems:"center",justifyContent:"center",cursor:tk.done&&role==="admin"?"pointer":can?"pointer":"not-allowed",flexShrink:0,marginTop:1}}>{tk.done&&<span style={{color:"#fff",fontSize:8}}>✓</span>}{isA&&!tk.done&&<span style={{color:th.cyan,fontSize:6}}>⚡</span>}{bl&&!tk.done&&<span style={{color:th.textMuted,fontSize:6}}>🔒</span>}</div>
    <div style={{flex:1,minWidth:0}}><div style={{display:"flex",alignItems:"center",gap:3,flexWrap:"wrap"}}><span style={{color:tk.done?th.textMuted:th.text,fontSize:10.5,fontWeight:500,textDecoration:tk.done?"line-through":"none"}}>{lang==="tr"?tk.text:tk.textEn}</span><span style={{color:tC,fontSize:7,fontWeight:700,padding:"0 3px",borderRadius:3,background:`${tC}12`,textTransform:"uppercase"}}>{tL}</span><span style={{color:th.textMuted,fontSize:8,padding:"0 3px",borderRadius:3,background:th.surface}}>{tk.assignee}</span>{bl&&<span style={{color:th.warning,fontSize:8}}>🔒</span>}</div>
    <div style={{display:"flex",gap:6,marginTop:1}}>{sla&&<span style={{color:isOD?th.danger:tk.done?th.textMuted:th.textSecondary,fontSize:9,fontWeight:isOD?600:400}}>{t.sla}: {fmtSla(sla)}{isOD&&` (${t.overdue})`}</span>}<span style={{color:th.textMuted,fontSize:8.5}}>{lang==="tr"?tk.criteria:tk.criteriaEn}</span></div>
    {bl&&<div style={{color:th.warning,fontSize:8.5,marginTop:1}}>{t.blockedBy} {getBlockerNames(tk,tasks,lang).join(", ")}</div>}
    {tk.done&&<div style={{display:"flex",gap:5,marginTop:1,fontSize:8.5,color:th.success}}><span>✓ {tk.completedBy}</span><span style={{color:th.textMuted}}>{tk.completedAt}</span>{tk.evidenceNote&&<span style={{color:th.accent,fontStyle:"italic"}}>📎 {tk.evidenceNote}</span>}</div>}</div></div>);})}</div>);})}</div></div>);
}

/* DRAFT BL MODAL */
function DraftBlModal({booking:b,lang,th,cu,onSave,onClose}){
  const t=L[lang];
  const[blFields,setBlFields]=useState({issuePlace:b.blDraftFields?.issuePlace||"",issueDate:b.blDraftFields?.issueDate||todayStr(),originalsCount:b.blDraftFields?.originalsCount||"3",freightPayableAt:b.blDraftFields?.freightPayableAt||""});
  const bWithFields={...b,blDraftFields:blFields};
  const missingFields=getDraftBlMissingFields(bWithFields);
  const totalFields=DRAFT_BL_REQUIRED_FIELDS.length;
  const readyCount=totalFields-missingFields.length;
  const readyPct=Math.round(readyCount/totalFields*100);
  const canGenerate=missingFields.length===0;
  const[showPreview,setShowPreview]=useState(false);
  const[previewHtml,setPreviewHtml]=useState("");
  const inp={width:"100%",padding:"4px 6px",borderRadius:4,border:`1px solid ${th.inputBorder}`,background:th.inputBg,color:th.text,fontSize:10.5,fontFamily:"'DM Sans',sans-serif",boxSizing:"border-box"};
  const lbl={color:th.textMuted,fontSize:9.5,fontWeight:600,marginBottom:2,marginTop:6,display:"block"};
  const handleGenerate=()=>{
    const data=getDraftBlData(bWithFields);
    const html=generateDraftBlHtml(data);
    setPreviewHtml(html);
    setShowPreview(true);
  };
  const handleSave=()=>{
    const data=getDraftBlData(bWithFields);
    const html=generateDraftBlHtml(data);
    const updated=saveDraftBlDocument({...b,blDraftFields:blFields},html,cu);
    onSave(updated);
  };
  return(<div style={{position:"fixed",top:0,left:0,width:"100%",height:"100%",background:th.backdrop,zIndex:200,display:"flex",alignItems:"center",justifyContent:"center"}} onClick={onClose}>
    <div onClick={e=>e.stopPropagation()} style={{background:th.cardBg,borderRadius:10,padding:16,width:480,maxHeight:"90vh",overflowY:"auto",border:`1px solid ${th.cardBorder}`,fontFamily:"'DM Sans',sans-serif"}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
        <div style={{fontSize:13,fontWeight:700,color:th.text}}>📄 Draft BL — {b.id}</div>
        <button onClick={onClose} style={{background:th.surface,border:`1px solid ${th.cardBorder}`,borderRadius:5,color:th.text,padding:"2px 6px",cursor:"pointer",fontSize:9}}>✕</button>
      </div>
      {/* Readiness Progress */}
      <div style={{background:th.surface,borderRadius:6,padding:"8px 10px",marginBottom:10,border:`1px solid ${th.divider}`}}>
        <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
          <span style={{color:th.text,fontSize:10.5,fontWeight:600}}>Draft BL Readiness</span>
          <span style={{color:readyPct===100?th.success:th.accent,fontSize:11,fontWeight:700,fontFamily:"'Space Mono',monospace"}}>{readyCount}/{totalFields}</span>
        </div>
        <PBar pct={readyPct} th={th} h={5}/>
        {missingFields.length>0&&<div style={{marginTop:6}}>
          <div style={{color:th.textMuted,fontSize:9,fontWeight:600,marginBottom:3}}>EKSİK ALANLAR:</div>
          <div style={{display:"flex",flexWrap:"wrap",gap:3}}>{missingFields.map((f,i)=><span key={i} style={{padding:"1px 5px",borderRadius:4,fontSize:8.5,color:th.danger,background:th.dangerBg,fontWeight:600}}>{f.label}</span>)}</div>
        </div>}
      </div>
      {/* BL-specific fields */}
      <div style={{marginBottom:10}}>
        <div style={{color:th.text,fontSize:10,fontWeight:700,textTransform:"uppercase",letterSpacing:".04em",marginBottom:6,borderBottom:`1px solid ${th.divider}`,paddingBottom:4}}>BL Alanları</div>
        <label style={lbl}>Place of Issue *</label>
        <input value={blFields.issuePlace} onChange={e=>setBlFields(p=>({...p,issuePlace:e.target.value}))} placeholder="İstanbul" style={{...inp,borderColor:!blFields.issuePlace?th.danger:th.inputBorder}}/>
        <label style={lbl}>Issue Date *</label>
        <input type="date" value={blFields.issueDate} onChange={e=>setBlFields(p=>({...p,issueDate:e.target.value}))} style={{...inp,borderColor:!blFields.issueDate?th.danger:th.inputBorder}}/>
        <label style={lbl}>No. of Original BLs</label>
        <input value={blFields.originalsCount} onChange={e=>setBlFields(p=>({...p,originalsCount:e.target.value}))} placeholder="3" style={inp}/>
        <label style={lbl}>Freight Payable At</label>
        <input value={blFields.freightPayableAt} onChange={e=>setBlFields(p=>({...p,freightPayableAt:e.target.value}))} placeholder="Hamburg" style={inp}/>
      </div>
      {/* Auto-filled preview */}
      <div style={{marginBottom:10,padding:"6px 8px",borderRadius:5,background:th.accentBg,border:`1px solid ${th.accentSoft}`,fontSize:9.5,color:th.accent}}>
        <span style={{fontWeight:700}}>Auto-filled: </span>
        {[b.shipper||b.customer,b.consignee,b.origin,b.destination,(b.schedule||{}).vessel,(b.schedule||{}).voyage].filter(Boolean).join(" · ")||"—"}
      </div>
      <div style={{display:"flex",gap:6,justifyContent:"flex-end"}}>
        <button onClick={onClose} style={{padding:"5px 10px",borderRadius:5,border:`1px solid ${th.cardBorder}`,background:"transparent",color:th.textSecondary,cursor:"pointer",fontSize:10.5,fontFamily:"'DM Sans',sans-serif"}}>{t.cancel}</button>
        <button onClick={handleGenerate} disabled={!canGenerate} style={{padding:"5px 10px",borderRadius:5,border:"none",background:canGenerate?th.accentSoft:th.blocked,color:canGenerate?th.accent:th.textMuted,cursor:canGenerate?"pointer":"not-allowed",fontSize:10.5,fontWeight:600,fontFamily:"'DM Sans',sans-serif"}}>
          {!canGenerate?`⚠ ${missingFields.length} alan eksik`:"👁 Preview"}
        </button>
        {canGenerate&&<button onClick={handleSave} style={{padding:"5px 12px",borderRadius:5,border:"none",background:th.gradient,color:th.gradientText,cursor:"pointer",fontSize:10.5,fontWeight:600,fontFamily:"'DM Sans',sans-serif"}}>💾 Save Draft BL</button>}
      </div>
    </div>
    {showPreview&&<div style={{position:"fixed",top:0,left:0,width:"100%",height:"100%",background:th.backdrop,zIndex:300,display:"flex",alignItems:"center",justifyContent:"center"}} onClick={()=>setShowPreview(false)}>
      <div onClick={e=>e.stopPropagation()} style={{background:"#fff",borderRadius:10,width:700,maxHeight:"90vh",overflow:"hidden",display:"flex",flexDirection:"column",boxShadow:"0 20px 60px rgba(0,0,0,.3)"}}>
        <div style={{padding:"8px 12px",borderBottom:"1px solid #e5e8ed",display:"flex",justifyContent:"space-between",alignItems:"center",background:"#f3f5f8"}}>
          <span style={{fontSize:12,fontWeight:700,color:"#1a2332"}}>📄 Draft BL Preview — {b.id}</span>
          <div style={{display:"flex",gap:6}}>
            <button onClick={handleSave} style={{padding:"4px 10px",borderRadius:5,border:"none",background:"#2563eb",color:"#fff",cursor:"pointer",fontSize:10,fontWeight:600,fontFamily:"'DM Sans',sans-serif"}}>💾 Onayla & Kaydet</button>
            <button onClick={()=>setShowPreview(false)} style={{padding:"4px 8px",borderRadius:5,border:"1px solid #dde1e8",background:"#fff",color:"#4a5568",cursor:"pointer",fontSize:10}}>✕ Kapat</button>
          </div>
        </div>
        <div style={{flex:1,overflowY:"auto"}}>
          <iframe srcDoc={previewHtml} style={{width:"100%",height:"600px",border:"none"}} title="Draft BL Preview"/>
        </div>
      </div>
    </div>}
  </div>);
}

/* DETAIL TAB */
function DetailTab({booking:b,lang,th,onUpdate,cu}){
  const t=L[lang];const[pvDoc,setPvDoc]=useState(null);const[showUp,setShowUp]=useState(false);const[upType,setUpType]=useState("hbl");
  const[showDraftBl,setShowDraftBl]=useState(false);
  const buy=getBuy(b);const sell=getSell(b);const profit=sell-buy;const mixed=hasMixedCcy(b);const missing=getMissing(b);const s=b.schedule||{};const c=b.cutoffs||{};const eq=b.equipment||{};
  let slip=null;try{slip=etaSlipDays(b);}catch(e){}
  const missingReq=getMissingReqDocs(b);
  const draftBlMissing=getDraftBlMissingFields(b);
  const draftBlReady=DRAFT_BL_REQUIRED_FIELDS.length-draftBlMissing.length;
  const draftBlTotal=DRAFT_BL_REQUIRED_FIELDS.length;
  const hasDraftBl=b.documents?.some(d=>d.type==="draft_bl");
  const doUp=()=>{const now=localNow();const nd={name:t[upType]||upType,type:upType,date:todayStr(),status:"final",size:"—"};let u={...b,documents:[...(b.documents||[]),nd],auditLog:[{who:"Deniz D.",what:`${nd.name} yüklendi`,when:now,category:"docs"},...(b.auditLog||[])]};u=applyAutoRules(u);onUpdate(u);setShowUp(false);};
  return(<div style={{maxHeight:"calc(100vh - 160px)",overflowY:"auto"}}>
     {pvDoc&&<DocDrawer doc={pvDoc} th={th} t={t} onClose={()=>setPvDoc(null)}/>}
    {showDraftBl&&<DraftBlModal booking={b} lang={lang} th={th} cu={cu} onSave={(u)=>{onUpdate(applyAutoRules(u));setShowDraftBl(false);}} onClose={()=>setShowDraftBl(false)}/>}
    {showUp&&<div style={{position:"fixed",top:0,left:0,width:"100%",height:"100%",background:th.backdrop,zIndex:100,display:"flex",alignItems:"center",justifyContent:"center"}} onClick={()=>setShowUp(false)}><div onClick={e=>e.stopPropagation()} style={{background:th.cardBg,borderRadius:10,padding:16,width:340,border:`1px solid ${th.cardBorder}`,fontFamily:"'DM Sans',sans-serif"}}><div style={{fontSize:13,fontWeight:700,color:th.text,marginBottom:10}}>{t.uploadDoc}</div><div style={{border:`2px dashed ${th.divider}`,borderRadius:6,padding:20,textAlign:"center",marginBottom:8,cursor:"pointer"}}><div style={{fontSize:22}}>📁</div><div style={{color:th.textSecondary,fontSize:10.5}}>{t.selectFile}</div></div><select value={upType} onChange={e=>setUpType(e.target.value)} style={{width:"100%",padding:"5px",borderRadius:4,border:`1px solid ${th.inputBorder}`,background:th.inputBg,color:th.text,fontSize:10.5,fontFamily:"'DM Sans',sans-serif",marginBottom:6,boxSizing:"border-box"}}>{["hbl","mbl","packing","invoice","vgm","booking_conf","cmr","draft_bl","final_bl","do_doc","pod","si","other"].map(d=><option key={d} value={d}>{t[d]||d}</option>)}</select><div style={{display:"flex",gap:4,justifyContent:"flex-end"}}><button onClick={()=>setShowUp(false)} style={{padding:"5px 10px",borderRadius:5,border:`1px solid ${th.cardBorder}`,background:"transparent",color:th.textSecondary,cursor:"pointer",fontSize:10.5,fontFamily:"'DM Sans',sans-serif"}}>{t.cancel}</button><button onClick={doUp} style={{padding:"5px 10px",borderRadius:5,border:"none",background:th.gradient,color:th.gradientText,cursor:"pointer",fontSize:10.5,fontWeight:600,fontFamily:"'DM Sans',sans-serif"}}>{t.upload}</button></div></div></div>}
    <div style={{padding:"8px 12px",borderBottom:`1px solid ${th.divider}`,background:th.surfaceAlt,display:"flex",alignItems:"center",justifyContent:"center",gap:8}}><span style={{color:th.accent,fontSize:11.5,fontWeight:700,fontFamily:"'Space Mono',monospace"}}>{b.origin?.split("(")[1]?.replace(")","")}</span><span style={{fontSize:12}}>🚢</span><span style={{color:th.accent,fontSize:11.5,fontWeight:700,fontFamily:"'Space Mono',monospace"}}>{b.destination?.split("(")[1]?.replace(")","")}</span>{s.vessel&&<span style={{color:th.textMuted,fontSize:9.5}}>· {s.vessel}</span>}</div>
    <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(270px,1fr))"}}>
      <div style={{borderRight:`1px solid ${th.divider}`}}>
        <Section id="general" title={t.general} icon="📦" th={th}><IR label={t.customer} value={b.customer} th={th}/><IR label={t.agent} value={b.agent} th={th}/><IR label={t.shipper} value={b.shipper||b.customer} th={th}/><IR label={t.consignee} value={b.consignee} th={th} hl={!b.consignee?th.warning:null}/><IR label={t.incoterm} value={b.incoterm} th={th}/><IR label={t.commodity} value={b.commodity} th={th}/></Section>
        <Section id="containers" title={t.containers} icon="📦" badge={`${b.containers?.length||0}`} th={th}>{(b.containers||[]).map((cn,i)=><div key={i} style={{background:th.surface,borderRadius:5,padding:6,marginBottom:2,border:`1px solid ${th.divider}`}}><div style={{display:"flex",justifyContent:"space-between"}}><span style={{color:th.accent,fontFamily:"'Space Mono',monospace",fontSize:10.5,fontWeight:600}}>{cn.number}</span><span style={{color:cn.vgm?th.success:th.warning,fontSize:8.5,fontWeight:600}}>VGM {cn.vgm?"✓":"⏳"}</span></div><IR label={t.type} value={cn.type} th={th}/><IR label={t.weight} value={cn.weight} th={th}/></div>)}{(!b.containers?.length)&&<div style={{color:th.textMuted,fontSize:10.5,textAlign:"center",padding:5}}>{t.noData}</div>}</Section>
        <Section id="equipment" title={t.equipment} icon="🏗️" th={th} defaultOpen={false}><IR label={t.emptyEarliest} value={eq.emptyEarliest} th={th}/><IR label={t.planned} value={eq.emptyPlanned} th={th}/><IR label={t.actual} value={eq.emptyActual} th={th}/><IR label="Stuffing" value={eq.stuffingPlanned} th={th}/><IR label="Gate-in" value={eq.gateInActual} th={th}/></Section>
      </div>
      <div>
        <Section id="datesVessel" title={t.datesVessel} icon="📅" th={th} alert={slip&&slip!==0?`${slip>0?"+":""}${slip} ${t.days}`:null}>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr"}}><div style={{paddingRight:6,borderRight:`1px solid ${th.divider}`}}><div style={{color:th.textMuted,fontSize:9,fontWeight:600,textTransform:"uppercase",marginBottom:2}}>{t.planned}</div><IR label={t.vessel} value={s.vessel} th={th}/><IR label={t.voyage} value={s.voyage} th={th}/><IR label={t.etd} value={s.etdPlanned} th={th}/><IR label={t.eta} value={s.etaPlanned} th={th}/></div><div style={{paddingLeft:6}}><div style={{color:th.accent,fontSize:9,fontWeight:600,textTransform:"uppercase",marginBottom:2}}>{t.actual}</div><IR label={t.etd} value={s.etdActual} th={th} hl={s.etdActual&&s.etdActual!==s.etdPlanned?th.warning:null}/><IR label={t.eta} value={s.etaActual} th={th} hl={s.etaActual&&s.etaActual!==s.etaPlanned?th.danger:null}/></div></div>
        </Section>
        <Section id="cutoffs" title={t.cutoffs} icon="⏰" th={th} defaultOpen={false}><IR label={t.siCutoff} value={c.si} th={th} hl={c.si&&safeHoursUntil(c.si)<24?th.danger:null}/><IR label={t.vgmCutoff} value={c.vgm} th={th} hl={c.vgm&&safeHoursUntil(c.vgm)<24?th.danger:null}/><IR label={t.cyCutoff} value={c.cy} th={th} hl={c.cy&&safeHoursUntil(c.cy)<24?th.danger:null}/></Section>
        <Section id="finance" title={t.chargeLines} icon="💰" badge={`${(b.charges||[]).length}`} th={th}><div style={{overflowX:"auto"}}><table style={{width:"100%",borderCollapse:"collapse",fontSize:10}}><thead><tr style={{borderBottom:`2px solid ${th.divider}`}}>{[t.chargeType,t.buySell,t.vendor,t.amount,t.status].map((h,i)=><th key={i} style={{padding:"3px 2px",textAlign:"left",color:th.textMuted,fontSize:8.5,fontWeight:600,textTransform:"uppercase"}}>{h}</th>)}</tr></thead><tbody>{(b.charges||[]).map((ch,i)=>{const cs=chSt(ch.status,th,lang);return(<tr key={i} style={{borderBottom:`1px solid ${th.divider}`}}><td style={{padding:"3px 2px",color:th.text}}>{ch.type}</td><td style={{padding:"3px 2px"}}><span style={{color:ch.bs==="buy"?th.danger:th.success,fontSize:8.5,fontWeight:700}}>{ch.bs==="buy"?"BUY":"SELL"}</span></td><td style={{padding:"3px 2px",color:th.textSecondary,fontSize:9.5}}>{ch.vendor}</td><td style={{padding:"3px 2px",fontFamily:"'Space Mono',monospace",fontWeight:600}}>{money(ch.actual??ch.est,ch.ccy,lang)}</td><td style={{padding:"3px 2px"}}><span style={{color:cs.c,fontSize:8,fontWeight:600,padding:"0 3px",borderRadius:4,background:`${cs.c}12`}}>{cs.l}</span></td></tr>);})}</tbody></table></div>
          {mixed?<div style={{marginTop:5,padding:6,borderRadius:5,background:th.purpleBg,textAlign:"center"}}><span style={{color:th.purple,fontSize:10,fontWeight:600}}>⚡ {t.mixedCcy}</span></div>:<div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:4,marginTop:5}}>{[{l:t.totalBuy,v:buy,c:th.danger},{l:t.totalSell,v:sell,c:th.success},{l:t.netProfit,v:profit,c:th.accent}].map((f,i)=><div key={i} style={{background:th.surface,borderRadius:4,padding:5,textAlign:"center"}}><div style={{color:th.textMuted,fontSize:8,textTransform:"uppercase"}}>{f.l}</div><div style={{color:f.c,fontSize:13,fontWeight:700,fontFamily:"'Space Mono',monospace"}}>{money(f.v,"USD",lang)}</div></div>)}</div>}
        </Section>
      </div>
    </div>
    <Section id="draftBl" title="Draft BL" icon="📄" th={th} badge={hasDraftBl?"✓":null} alert={!hasDraftBl&&draftBlMissing.length>0?`${draftBlMissing.length} eksik`:null}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:6}}>
        <div style={{flex:1}}>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:3}}>
            <span style={{color:th.textSecondary,fontSize:9.5}}>Readiness</span>
            <span style={{color:draftBlReady===draftBlTotal?th.success:th.accent,fontSize:9.5,fontWeight:700,fontFamily:"'Space Mono',monospace"}}>{draftBlReady}/{draftBlTotal}</span>
          </div>
          <PBar pct={Math.round(draftBlReady/draftBlTotal*100)} th={th} h={4}/>
          {draftBlMissing.length>0&&<div style={{display:"flex",flexWrap:"wrap",gap:2,marginTop:4}}>{draftBlMissing.slice(0,4).map((f,i)=><span key={i} style={{padding:"1px 4px",borderRadius:3,fontSize:8,color:th.danger,background:th.dangerBg}}>{f.label}</span>)}{draftBlMissing.length>4&&<span style={{padding:"1px 4px",borderRadius:3,fontSize:8,color:th.textMuted,background:th.surface}}>+{draftBlMissing.length-4} more</span>}</div>}
          {hasDraftBl&&<div style={{marginTop:4,color:th.success,fontSize:9.5,fontWeight:600}}>✓ Draft BL kaydedildi</div>}
        </div>
        <button onClick={()=>setShowDraftBl(true)} style={{marginLeft:10,padding:"5px 10px",borderRadius:5,border:`1px solid ${draftBlMissing.length>0?th.cardBorder:"transparent"}`,background:draftBlMissing.length>0?th.surface:th.gradient,color:draftBlMissing.length>0?th.textSecondary:th.gradientText,cursor:"pointer",fontSize:9.5,fontWeight:600,fontFamily:"'DM Sans',sans-serif",flexShrink:0}}>
          {hasDraftBl?"📄 Yenile":draftBlMissing.length>0?`⚠ ${draftBlMissing.length} eksik`:"📄 Generate"}
        </button>
      </div>
    </Section>
    <Section id="documents" title={t.documents} icon="📄" badge={`${b.documents?.length||0}`} th={th} alert={missingReq.length>0?`${missingReq.length} ${t.missingRequired}`:null}>{missingReq.length>0&&<div style={{marginBottom:4,padding:"4px 6px",borderRadius:4,background:th.warningBg,fontSize:9.5,color:th.warning}}>{t.requiredDocs}: {missingReq.map(r=>t[r]||r).join(", ")}</div>}<div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(140px,1fr))",gap:3}}>{(b.documents||[]).map((d,i)=><div key={i} onClick={()=>setPvDoc(d)} style={{background:th.surface,border:`1px solid ${th.divider}`,borderRadius:4,padding:6,cursor:"pointer"}} onMouseEnter={e=>e.currentTarget.style.borderColor=th.accent} onMouseLeave={e=>e.currentTarget.style.borderColor=th.divider}><div style={{display:"flex",alignItems:"center",gap:3}}><span style={{fontSize:10}}>{DOC_IC[d.type]||"📄"}</span><span style={{color:th.text,fontSize:10,fontWeight:500}}>{d.name}</span></div><div style={{display:"flex",justifyContent:"space-between"}}><span style={{color:th.textMuted,fontSize:8.5}}>{d.date}</span><span style={{fontSize:8,fontWeight:600,color:d.status==="final"?th.success:th.warning}}>{d.status}</span></div></div>)}<div onClick={()=>setShowUp(true)} style={{border:`2px dashed ${th.divider}`,borderRadius:4,padding:6,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",color:th.textMuted,fontSize:10}}>{t.addDoc}</div></div></Section>
    <Section id="tracking" title={t.tracking} icon="🗺️" th={th}>{(b.trackingEvents||[]).length>0?<div style={{display:"flex",padding:"4px 0"}}>{(b.trackingEvents||[]).map((te,i)=><div key={i} style={{flex:1,textAlign:"center",cursor:"pointer"}} onClick={()=>onUpdate({...b,trackingEvents:(b.trackingEvents||[]).map((x,j)=>j===i?{...x,done:!x.done}:x)})}><div style={{width:18,height:18,borderRadius:"50%",margin:"0 auto 2px",background:te.done?th.accent:th.cardBg,border:`2px solid ${te.done?th.accent:th.surface}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:8,color:te.done?th.gradientText:th.textMuted,fontWeight:700,position:"relative",zIndex:1}}>{te.done?"✓":(i+1)}</div><div style={{color:te.done?th.text:th.textMuted,fontSize:9,fontWeight:600}}>{te.event}</div><div style={{color:th.textMuted,fontSize:8}}>{te.location}</div></div>)}</div>:<div style={{color:th.textMuted,fontSize:10.5,textAlign:"center",padding:4}}>{t.noData}</div>}</Section>
    {missing.length>0&&<Section id="completeness" title={t.completeness} icon="⚠️" th={th} alert={`${missing.length}`} defaultOpen={false}><div style={{display:"flex",flexWrap:"wrap",gap:3}}>{missing.map((m,i)=><span key={i} style={{padding:"2px 6px",borderRadius:4,fontSize:9.5,color:th.warning,background:th.warningBg,cursor:"pointer"}}>{t[m.key]} <span style={{fontSize:8,color:th.accent}}>{t.goToSection}</span></span>)}</div></Section>}
    <Section id="notes" title={t.notes} icon="💬" badge={`${b.notes?.length||0}`} th={th}>{(b.notes||[]).map((n,i)=><div key={i} style={{display:"flex",gap:5,padding:5,background:th.surface,borderRadius:4,border:`1px solid ${th.divider}`,marginBottom:2}}><div style={{width:22,height:22,borderRadius:"50%",background:th.accentSoft,display:"flex",alignItems:"center",justifyContent:"center",color:th.accent,fontSize:9,fontWeight:700,flexShrink:0}}>{n.user?.charAt(0)}</div><div style={{flex:1}}><div style={{display:"flex",gap:3}}><span style={{color:th.text,fontSize:9.5,fontWeight:600}}>{n.user}</span><span style={{color:th.textMuted,fontSize:8.5}}>{n.date}</span></div><div style={{color:th.textSecondary,fontSize:10.5}}>{n.text}</div></div></div>)}<div style={{padding:"5px 6px",background:th.surface,borderRadius:4,border:`1px solid ${th.divider}`,color:th.textMuted,fontSize:10.5,cursor:"pointer"}}>{t.addNote}</div></Section>
  </div>);
}

/* ADMIN PANEL */
function AdminPanel({bookings,lang,th,onSelectBooking,onUpdateBooking,cu,role}){
  const t=L[lang];const[tab,setTab]=useState("exceptions");const[raTk,setRaTk]=useState(null);
  const allOD=bookings.flatMap(b=>getODTasks(b).map(tk=>({...tk,booking:b,slaDate:calcSlaDate(b,tk)})));
  const fwdEx=bookings.flatMap(b=>deriveExceptions(b,lang).map(ex=>({...ex,booking:b})));
  const aging=bookings.filter(b=>{const la=getLastActionWhen(b);return!la||hoursDiff(la)>=48;});
  const wl=OPS.map(op=>{const mp=bookings.flatMap(b=>(b.workflowTasks||[]).filter(tk=>tk.assignee===op).map(tk=>({tk,b})));const open=mp.filter(({tk})=>!tk.done);const ov=open.filter(({tk,b:bd})=>isSlaOverdue(calcSlaDate(bd,tk)));const dt=mp.filter(({tk})=>tk.done&&tk.completedAt).map(({tk})=>tk.completedAt);return{name:op,total:mp.length,open:open.length,overdue:ov.length,doneToday:mp.filter(({tk})=>tk.done&&tk.completedAt?.startsWith(todayStr())).length,lastDone:dt.length?dt.reduce((a,c)=>a>c?a:c):null};});
  const allStory=bookings.flatMap(b=>buildStory(b,lang).map(i=>({...i,bookingId:b.id})));
  const allAudit=bookings.flatMap(b=>(b.auditLog||[]).map(a=>({...a,bookingId:b.id})));
  const doNudge=(tk)=>{const now=localNow();onUpdateBooking({...tk.booking,auditLog:[{who:cu,what:`${tk.assignee} ${t.nudged} — ${lang==="tr"?tk.text:tk.textEn}`,when:now,category:"task"},...(tk.booking.auditLog||[])]});};
  const doReassign=(nA)=>{if(!raTk)return;const now=localNow();const bk=raTk.booking;onUpdateBooking({...bk,workflowTasks:(bk.workflowTasks||[]).map(tk=>tk.id===raTk.id?{...tk,assignee:nA}:tk),auditLog:[{who:cu,what:`${raTk.assignee} → ${nA} ${t.reassigned}`,when:now,category:"task"},...(bk.auditLog||[])]});setRaTk(null);};
  const mixC=bookings.filter(b=>hasMixedCcy(b)).length;const clean=bookings.filter(b=>!hasMixedCcy(b));
  return(<div>{raTk&&<ReassignModal task={raTk} th={th} lang={lang} onSave={doReassign} onClose={()=>setRaTk(null)}/>}
    <div style={{padding:"10px 16px",borderBottom:`1px solid ${th.divider}`,background:th.cardBg}}><h1 style={{fontSize:15,fontWeight:700,margin:0,color:th.text}}>🛡️ {t.adminTitle}</h1></div>
    <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(110px,1fr))",gap:5,padding:"8px 16px",borderBottom:`1px solid ${th.divider}`}}>{[{l:t.total,v:bookings.length,c:th.text},{l:t.overdueTasks,v:allOD.length,c:allOD.length?th.danger:th.success},{l:t.exceptionsBoard,v:fwdEx.length,c:fwdEx.length?th.warning:th.success},{l:t.avgMargin+(mixC?` (-${mixC})`:""),v:(()=>{const r=clean.reduce((s,b)=>s+getSell(b),0);const c_=clean.reduce((s,b)=>s+getBuy(b),0);return r?Math.round((r-c_)/r*100)+"%":"—";})(),c:th.accent}].map((s,i)=><div key={i} style={{background:th.cardBg,border:`1px solid ${th.cardBorder}`,borderRadius:7,padding:"7px 9px",boxShadow:th.shadow}}><div style={{color:th.textMuted,fontSize:8.5,fontWeight:600,textTransform:"uppercase"}}>{s.l}</div><div style={{color:s.c,fontSize:16,fontWeight:700,fontFamily:"'Space Mono',monospace"}}>{s.v}</div></div>)}</div>
    <div style={{display:"flex",borderBottom:`1px solid ${th.divider}`,background:th.surfaceAlt}}>{[{key:"exceptions",label:t.exceptionsBoard,badge:fwdEx.length+allOD.length},{key:"workload",label:t.workload},{key:"story",label:t.storyMode+"/"+t.forensicMode}].map(tb=><button key={tb.key} onClick={()=>setTab(tb.key)} style={{padding:"7px 12px",border:"none",borderBottom:`2px solid ${tab===tb.key?th.accent:"transparent"}`,background:"transparent",color:tab===tb.key?th.accent:th.textSecondary,fontSize:10.5,fontWeight:600,cursor:"pointer",fontFamily:"'DM Sans',sans-serif"}}>{tb.label}{tb.badge>0&&<span style={{marginLeft:3,color:th.danger,background:th.dangerBg,padding:"1px 4px",borderRadius:6,fontSize:8.5,fontWeight:700}}>{tb.badge}</span>}</button>)}</div>
    <div style={{maxHeight:"calc(100vh - 220px)",overflowY:"auto"}}>
      {tab==="exceptions"&&<div>
        {fwdEx.length>0&&<div style={{padding:"6px 12px",borderBottom:`1px solid ${th.divider}`}}><div style={{color:th.text,fontSize:11,fontWeight:600,marginBottom:4}}>⚡ Forwarder Alarmları</div>{fwdEx.map((ex,i)=><div key={i} style={{display:"flex",alignItems:"center",gap:6,padding:"4px 0",borderBottom:`1px solid ${th.divider}`}}><span style={{color:ex.severity==="critical"?th.danger:th.warning,fontSize:8.5,fontWeight:700,padding:"1px 4px",borderRadius:4,background:ex.severity==="critical"?th.dangerBg:th.warningBg}}>{ex.severity==="critical"?t.critical:t.warn}</span><span onClick={()=>onSelectBooking(ex.booking)} style={{color:th.accent,fontFamily:"'Space Mono',monospace",fontSize:10,fontWeight:600,cursor:"pointer"}}>{ex.bookingId}</span><span style={{color:th.text,fontSize:10,flex:1}}>{ex.label}</span><button onClick={()=>onSelectBooking(ex.booking)} style={{padding:"1px 5px",borderRadius:3,border:`1px solid ${th.cardBorder}`,background:th.surface,color:th.accent,fontSize:8,cursor:"pointer",fontFamily:"'DM Sans',sans-serif"}}>{t.jumpToSection}</button></div>)}</div>}
        {allOD.length>0&&<div style={{padding:"6px 12px"}}><div style={{color:th.text,fontSize:11,fontWeight:600,marginBottom:4}}>⏰ {t.overdueTasks} ({allOD.length})</div><table style={{width:"100%",borderCollapse:"collapse",fontSize:10}}><thead><tr style={{borderBottom:`2px solid ${th.divider}`}}>{[t.fileRef,t.task,t.sla,t.assignee,""].map((h,i)=><th key={i} style={{padding:"4px 6px",textAlign:"left",color:th.textMuted,fontSize:8.5,fontWeight:600,textTransform:"uppercase"}}>{h}</th>)}</tr></thead><tbody>{allOD.map((tk,i)=><tr key={i} style={{borderBottom:`1px solid ${th.divider}`,background:th.overdueBg}}><td style={{padding:"4px 6px"}}><span onClick={()=>onSelectBooking(tk.booking)} style={{color:th.accent,fontFamily:"'Space Mono',monospace",fontWeight:600,cursor:"pointer",fontSize:9.5}}>{tk.booking.id}</span></td><td style={{padding:"4px 6px",color:th.text}}>{lang==="tr"?tk.text:tk.textEn}</td><td style={{padding:"4px 6px",color:th.danger,fontFamily:"'Space Mono',monospace"}}>{fmtSla(tk.slaDate)}</td><td style={{padding:"4px 6px",color:th.textSecondary}}>{tk.assignee}</td><td style={{padding:"4px 6px"}}><div style={{display:"flex",gap:2}}><button onClick={()=>onSelectBooking(tk.booking)} style={{padding:"1px 4px",borderRadius:3,border:`1px solid ${th.cardBorder}`,background:th.surface,color:th.accent,fontSize:8,cursor:"pointer",fontFamily:"'DM Sans',sans-serif"}}>{t.openFile}</button>{role==="admin"&&<><button onClick={()=>doNudge(tk)} style={{padding:"1px 4px",borderRadius:3,border:`1px solid ${th.cardBorder}`,background:th.surface,color:th.warning,fontSize:8,cursor:"pointer",fontFamily:"'DM Sans',sans-serif"}}>{t.nudge}</button><button onClick={()=>setRaTk(tk)} style={{padding:"1px 4px",borderRadius:3,border:`1px solid ${th.cardBorder}`,background:th.surface,color:th.purple,fontSize:8,cursor:"pointer",fontFamily:"'DM Sans',sans-serif"}}>{t.reassign}</button></>}</div></td></tr>)}</tbody></table></div>}
        {!fwdEx.length&&!allOD.length&&<div style={{padding:16,textAlign:"center",color:th.success,fontSize:12}}>{t.noOverdue}</div>}
      </div>}
      {tab==="workload"&&<div style={{padding:10}}><div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(170px,1fr))",gap:7}}>{wl.map((w,i)=><div key={i} style={{background:th.cardBg,border:`1px solid ${th.cardBorder}`,borderRadius:8,padding:10,boxShadow:th.shadow}}><div style={{display:"flex",alignItems:"center",gap:5,marginBottom:6}}><div style={{width:26,height:26,borderRadius:"50%",background:th.accentSoft,display:"flex",alignItems:"center",justifyContent:"center",color:th.accent,fontSize:10,fontWeight:700}}>{w.name.charAt(0)}</div><div><div style={{color:th.text,fontSize:11.5,fontWeight:600}}>{w.name}</div><div style={{color:th.textMuted,fontSize:9}}>{w.total} {t.total.toLowerCase()}</div></div></div><div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:3}}>{[{l:t.openTasks,v:w.open,c:th.accent},{l:t.overdueCount,v:w.overdue,c:w.overdue?th.danger:th.success},{l:t.completedToday,v:w.doneToday,c:th.success}].map((s,j)=><div key={j} style={{textAlign:"center",padding:3,background:th.surface,borderRadius:3}}><div style={{color:th.textMuted,fontSize:7,textTransform:"uppercase"}}>{s.l}</div><div style={{color:s.c,fontSize:13,fontWeight:700,fontFamily:"'Space Mono',monospace"}}>{s.v}</div></div>)}</div>{w.lastDone&&<div style={{marginTop:3,color:th.textMuted,fontSize:8,textAlign:"right"}}>{t.lastAction}: {fmtDateTime(w.lastDone)}</div>}</div>)}</div></div>}
      {tab==="story"&&<StoryPanel items={allStory} auditLog={allAudit} lang={lang} th={th}/>}
    </div>
  </div>);
}

/* BOOKER PANEL */
function BookerPanel({bookings,lang,th,cu,onSelectBooking}){
  const t=L[lang];const myT=bookings.flatMap(b=>(b.workflowTasks||[]).filter(tk=>tk.assignee===cu&&!tk.done).map(tk=>({...tk,booking:b,slaDate:calcSlaDate(b,tk)})));
  const myOD=myT.filter(tk=>isSlaOverdue(tk.slaDate));const myToday=myT.filter(tk=>tk.slaDate?.slice(0,10)===todayStr()&&!isSlaOverdue(tk.slaDate));
  return(<div>
    <div style={{padding:"10px 16px",borderBottom:`1px solid ${th.divider}`,background:th.cardBg}}><h1 style={{fontSize:15,fontWeight:700,margin:0,color:th.text}}>⊞ {t.bookerTitle} — {cu}</h1></div>
    <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(110px,1fr))",gap:5,padding:"8px 16px",borderBottom:`1px solid ${th.divider}`}}>{[{l:t.myTasks,v:myT.length,c:th.accent},{l:t.overdueTasks,v:myOD.length,c:myOD.length?th.danger:th.success},{l:t.dueToday,v:myToday.length,c:myToday.length?th.warning:th.success},{l:t.allFiles,v:[...new Set(myT.map(tk=>tk.booking.id))].length,c:th.text}].map((s,i)=><div key={i} style={{background:th.cardBg,border:`1px solid ${th.cardBorder}`,borderRadius:7,padding:"7px 9px",boxShadow:th.shadow}}><div style={{color:th.textMuted,fontSize:8.5,fontWeight:600,textTransform:"uppercase"}}>{s.l}</div><div style={{color:s.c,fontSize:16,fontWeight:700,fontFamily:"'Space Mono',monospace"}}>{s.v}</div></div>)}</div>
    <div style={{maxHeight:"calc(100vh - 180px)",overflowY:"auto"}}>{!myT.length?<div style={{padding:20,textAlign:"center",color:th.success,fontSize:12}}>✓ {t.noOverdue}</div>:<table style={{width:"100%",borderCollapse:"collapse",fontSize:10}}><thead><tr style={{borderBottom:`2px solid ${th.divider}`,background:th.surfaceAlt}}>{[t.fileRef,t.task,t.sla,t.status,""].map((h,i)=><th key={i} style={{padding:"5px 6px",textAlign:"left",color:th.textMuted,fontSize:8.5,fontWeight:600,textTransform:"uppercase"}}>{h}</th>)}</tr></thead><tbody>{myT.sort((a,b_)=>slaToMs(a.slaDate)-slaToMs(b_.slaDate)).map((tk,i)=>{const isOD=isSlaOverdue(tk.slaDate);const bl=isBlocked(tk,tk.booking.workflowTasks||[]);return<tr key={i} style={{borderBottom:`1px solid ${th.divider}`,background:isOD?th.overdueBg:"transparent"}} onMouseEnter={e=>{if(!isOD)e.currentTarget.style.background=th.hover;}} onMouseLeave={e=>{e.currentTarget.style.background=isOD?th.overdueBg:"transparent";}}>
      <td style={{padding:"5px 6px"}}><span onClick={()=>onSelectBooking(tk.booking)} style={{color:th.accent,fontFamily:"'Space Mono',monospace",fontWeight:600,cursor:"pointer",fontSize:9.5}}>{tk.booking.id}</span></td>
      <td style={{padding:"5px 6px",color:bl?th.textMuted:th.text}}>{bl&&"🔒 "}{lang==="tr"?tk.text:tk.textEn}</td>
      <td style={{padding:"5px 6px",color:isOD?th.danger:th.textSecondary,fontFamily:"'Space Mono',monospace",fontWeight:isOD?600:400}}>{fmtSla(tk.slaDate)}{isOD&&` (${t.overdue})`}</td>
      <td style={{padding:"5px 6px"}}>{bl?<span style={{color:th.warning,fontSize:8.5}}>{t.blocked}</span>:isOD?<span style={{color:th.danger,fontSize:8.5}}>{t.overdue}</span>:<span style={{color:th.accent,fontSize:8.5}}>OK</span>}</td>
      <td style={{padding:"5px 6px"}}><button onClick={()=>onSelectBooking(tk.booking)} style={{padding:"1px 4px",borderRadius:3,border:`1px solid ${th.cardBorder}`,background:th.surface,color:th.accent,fontSize:8,cursor:"pointer",fontFamily:"'DM Sans',sans-serif"}}>{t.openFile}</button></td>
    </tr>;})}</tbody></table>}</div>
  </div>);
}

/* BOOKING DETAIL */
function BookingDetail({booking:b,lang,th,onBack,onUpdate,cu,role}){
  const t=L[lang];const[aTab,setATab]=useState("workflow");const[showQU,setShowQU]=useState(false);
  const dc=dirCfg(b.direction,th);const ss=stCfg(b.status,th);const prog=getWfProg(b);const odC=getODTasks(b).length;
  let slip=null;try{slip=etaSlipDays(b);}catch(e){}
  const nA=getNextAction(b,cu);const nSla=nA?calcSlaDate(b,nA):null;const nOD=isSlaOverdue(nSla);
  const story=buildStory(b,lang);
  useEffect(()=>{const h=(e)=>{if(e.key==="u"&&!e.metaKey&&!e.ctrlKey&&!["INPUT","TEXTAREA","SELECT"].includes(document.activeElement?.tagName))setShowQU(true);};document.addEventListener("keydown",h);return()=>document.removeEventListener("keydown",h);},[]);
  const doQU=(ev)=>{const now=localNow();let u={...b,events:[...(b.events||[]),ev],auditLog:[{who:cu,what:`${(EVENT_LBL[lang]||EVENT_LBL.en)[ev.type]}: ${ev.summary||""}`,when:now,category:"schedule"},...(b.auditLog||[])]};u=applyOperationalEvent(u,ev);onUpdate(u);setShowQU(false);};
  return(<div>
    {showQU&&<QuickUpdateModal booking={b} lang={lang} th={th} currentUser={cu} onSave={doQU} onClose={()=>setShowQU(false)}/>}
    <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"7px 12px",borderBottom:`1px solid ${th.divider}`,background:th.cardBg,flexWrap:"wrap",gap:3}}>
      <div style={{display:"flex",alignItems:"center",gap:6,flexWrap:"wrap"}}>
        <button onClick={onBack} style={{background:"none",border:"none",color:th.textSecondary,cursor:"pointer",fontSize:11.5,fontFamily:"'DM Sans',sans-serif"}}>{t.back}</button>
        <span style={{color:th.accent,fontSize:13,fontWeight:700,fontFamily:"'Space Mono',monospace"}}>{b.id}</span>
        <span style={{color:dc.c,fontSize:7.5,fontWeight:700,padding:"1px 4px",borderRadius:3,background:`${dc.c}12`}}>{lang==="tr"?dc.tr:dc.en}</span>
        <span style={{padding:"2px 6px",borderRadius:8,fontSize:9,fontWeight:600,color:ss.c,background:ss.bg}}>{t[statusKey[b.status]]}</span>
        {b.flags?.rolled&&<span style={{padding:"1px 5px",borderRadius:6,fontSize:8.5,fontWeight:700,color:th.danger,background:th.dangerBg}}>⚓ ROLLED</span>}
        {odC>0&&<span style={{padding:"1px 4px",borderRadius:6,fontSize:8.5,fontWeight:700,color:th.danger,background:th.dangerBg}}>⚠ {odC}</span>}
        {slip&&slip!==0&&<span style={{padding:"1px 4px",borderRadius:6,fontSize:8.5,fontWeight:600,color:slip>0?th.danger:th.success,background:slip>0?th.dangerBg:th.successBg}}>ETA {slip>0?"+":""}{slip}{t.days}</span>}
      </div>
      <div style={{display:"flex",alignItems:"center",gap:4}}>
        <button onClick={()=>setShowQU(true)} style={{padding:"3px 8px",borderRadius:5,border:`1px solid ${th.cardBorder}`,background:th.surface,color:th.accent,cursor:"pointer",fontSize:9.5,fontWeight:600,fontFamily:"'DM Sans',sans-serif"}}>{t.quickUpdateBtn} <kbd style={{fontSize:7,opacity:.6}}>U</kbd></button>
        <span style={{color:th.textSecondary,fontSize:10}}>{b.customer}</span>
        <span style={{color:th.textMuted,fontSize:9,fontFamily:"'Space Mono',monospace"}}>{prog.pct}%</span>
        <div style={{width:36}}><PBar pct={prog.pct} th={th} h={3}/></div>
      </div>
    </div>
    {nA&&<div style={{padding:"5px 12px",borderBottom:`1px solid ${th.divider}`,background:nOD?th.overdueBg:th.accentBg,display:"flex",alignItems:"center",gap:6,flexWrap:"wrap"}}>
      <span style={{color:nOD?th.danger:th.accent,fontSize:9.5,fontWeight:700}}>▶ {lang==="tr"?"Sıradaki":"Next"}:</span>
      <span style={{color:th.text,fontSize:10,fontWeight:500}}>{lang==="tr"?nA.text:nA.textEn}</span>
      <span style={{color:th.textMuted,fontSize:8.5,padding:"0 3px",borderRadius:3,background:th.surface}}>{nA.assignee}</span>
      {nSla&&<span style={{color:nOD?th.danger:th.textSecondary,fontSize:9,fontFamily:"'Space Mono',monospace"}}>{fmtSla(nSla)}{nOD&&` (${t.overdue})`}</span>}
    </div>}
    <div style={{display:"flex",borderBottom:`1px solid ${th.divider}`,background:th.cardBg}}>
      {[{key:"workflow",label:t.workflowTab,icon:"📋"},{key:"detail",label:t.detailTab,icon:"📦"},{key:"timeline",label:t.storyMode,icon:"📖"}].map(tb=>
        <button key={tb.key} onClick={()=>setATab(tb.key)} style={{padding:"6px 14px",border:"none",borderBottom:`2px solid ${aTab===tb.key?th.accent:"transparent"}`,background:"transparent",color:aTab===tb.key?th.accent:th.textSecondary,fontSize:10.5,fontWeight:600,cursor:"pointer",fontFamily:"'DM Sans',sans-serif"}}>{tb.icon} {tb.label}</button>)}
    </div>
    {aTab==="workflow"?<WorkflowTab booking={b} lang={lang} th={th} onUpdate={onUpdate} cu={cu} role={role}/>:aTab==="detail"?<DetailTab booking={b} lang={lang} th={th} onUpdate={onUpdate} cu={cu}/>:<StoryPanel items={story} auditLog={b.auditLog} lang={lang} th={th}/>}
  </div>);
}

/* MAIN APP */
export default function App(){
  const[theme,setTheme]=useState("light");const[lang,setLang]=useState("tr");
  const[cu,setCu]=useState("Deniz D.");const[role,setRole]=useState("admin");
  const raw=initBookings();raw.forEach(b=>{if(!b.workflowTasks){const tpl=b.templateType==="import"?IM_TPL:EX_TPL;b.workflowTasks=genTasks(tpl,b.id,WF_OV[b.id]||{});}});
  const[bookings,setBookings]=useState(raw.map(b=>applyAutoRules(b)));
  const[sel,setSel]=useState(null);const[page,setPage]=useState("booker");
  const[fSt,setFSt]=useState("all");const[exc,setExc]=useState(null);const[cmdK,setCmdK]=useState(false);
  const th=TH[theme];const t=L[lang];
  useEffect(()=>{const h=(e)=>{if((e.metaKey||e.ctrlKey)&&e.key==="k"){e.preventDefault();setCmdK(true);}};document.addEventListener("keydown",h);return()=>document.removeEventListener("keydown",h);},[]);
  const handleUp=useCallback((u)=>{setBookings(p=>p.map(b=>b.id===u.id?u:b));setSel(u);},[]);
  const selFromPanel=(b)=>{setSel(b);setPage("booker");};
  const totalOD=bookings.reduce((s,b)=>s+getODTasks(b).length,0);
  const filtered=bookings.filter(b=>{if(fSt!=="all"&&b.status!==fSt)return false;if(exc==="overdue"&&!getODTasks(b).length)return false;return true;});
  return(
    <div style={{fontFamily:"'DM Sans',sans-serif",background:th.bg,color:th.text,minHeight:"100vh",display:"flex"}}>
      <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet"/>
      {cmdK&&<div style={{position:"fixed",top:0,left:0,width:"100%",height:"100%",background:th.backdrop,zIndex:200,display:"flex",alignItems:"flex-start",justifyContent:"center",paddingTop:"12vh"}} onClick={()=>setCmdK(false)}><div onClick={e=>e.stopPropagation()} style={{width:420,background:th.cardBg,borderRadius:10,border:`1px solid ${th.cardBorder}`,boxShadow:"0 20px 60px rgba(0,0,0,.3)",overflow:"hidden"}}><CmdK bookings={bookings} th={th} t={t} lang={lang} onSelect={b=>{setSel(b);setPage("booker");setCmdK(false);}} onClose={()=>setCmdK(false)}/></div></div>}
      <div style={{width:172,background:th.sidebar,borderRight:`1px solid ${th.sidebarBorder}`,display:"flex",flexDirection:"column",flexShrink:0}}>
        <div style={{padding:"10px 8px",borderBottom:`1px solid ${th.sidebarBorder}`}}><div style={{display:"flex",alignItems:"center",gap:5}}><div style={{width:22,height:22,borderRadius:4,background:th.gradient,display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:700,color:th.gradientText}}>F</div><span style={{fontSize:13,fontWeight:700,color:th.text}}>FreightFlow</span></div></div>
        <nav style={{padding:"3px 3px",flex:1}}>{[{k:"booker",icon:"⊞",l:t.booker,badge:totalOD||null,bc:th.danger},{k:"admin",icon:"🛡️",l:t.admin},{k:"customers",icon:"◉",l:t.customers},{k:"settings",icon:"⚙",l:t.settings}].map(item=><div key={item.k} onClick={()=>{setPage(item.k);setSel(null);}} style={{padding:"5px 6px",borderRadius:4,marginBottom:1,cursor:"pointer",display:"flex",alignItems:"center",gap:5,background:page===item.k?th.sidebarActive:"transparent",color:page===item.k?th.accent:th.textSecondary,fontSize:11,fontWeight:page===item.k?600:400}}><span style={{fontSize:9}}>{item.icon}</span>{item.l}{item.badge&&<span style={{marginLeft:"auto",fontSize:7.5,fontWeight:700,color:item.bc,background:`${item.bc}14`,padding:"1px 3px",borderRadius:4}}>{item.badge}</span>}</div>)}</nav>
        <div style={{padding:"5px 6px",borderTop:`1px solid ${th.sidebarBorder}`}}>
          <select value={cu} onChange={e=>setCu(e.target.value)} style={{width:"100%",padding:"2px 3px",borderRadius:3,border:`1px solid ${th.sidebarBorder}`,background:th.inputBg,color:th.text,fontSize:9,fontFamily:"'DM Sans',sans-serif",marginBottom:2,boxSizing:"border-box"}}>{OPS.map(op=><option key={op} value={op}>{op}</option>)}</select>
          <select value={role} onChange={e=>setRole(e.target.value)} style={{width:"100%",padding:"2px 3px",borderRadius:3,border:`1px solid ${th.sidebarBorder}`,background:th.inputBg,color:th.text,fontSize:9,fontFamily:"'DM Sans',sans-serif",marginBottom:2,boxSizing:"border-box"}}>{["admin","operator"].map(r=><option key={r} value={r}>{r==="admin"?"Admin":"Operator"}</option>)}</select>
          <div style={{display:"flex",borderRadius:3,overflow:"hidden",border:`1px solid ${th.sidebarBorder}`,marginBottom:2}}>{["light","dark"].map(k=><button key={k} onClick={()=>setTheme(k)} style={{flex:1,padding:"2px 0",border:"none",cursor:"pointer",background:theme===k?th.accent:"transparent",color:theme===k?th.gradientText:th.textMuted,fontSize:9,fontWeight:600,fontFamily:"'DM Sans',sans-serif"}}>{k==="light"?"☀️":"🌙"}</button>)}</div>
          <div style={{display:"flex",borderRadius:3,overflow:"hidden",border:`1px solid ${th.sidebarBorder}`}}>{["tr","en"].map(l=><button key={l} onClick={()=>setLang(l)} style={{flex:1,padding:"2px 0",border:"none",cursor:"pointer",background:lang===l?th.accent:"transparent",color:lang===l?th.gradientText:th.textMuted,fontSize:8,fontWeight:700,fontFamily:"'DM Sans',sans-serif"}}>{l.toUpperCase()}</button>)}</div>
        </div>
      </div>
      <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden",minWidth:0}}>
        {page==="admin"?<AdminPanel bookings={bookings} lang={lang} th={th} onSelectBooking={selFromPanel} onUpdateBooking={handleUp} cu={cu} role={role}/>:
        sel?<BookingDetail booking={sel} lang={lang} th={th} onBack={()=>setSel(null)} onUpdate={handleUp} cu={cu} role={role}/>:
        page==="booker"?(<>
          <div style={{padding:"7px 12px",borderBottom:`1px solid ${th.divider}`,display:"flex",alignItems:"center",justifyContent:"space-between",background:th.cardBg,flexWrap:"wrap",gap:3}}>
            <h1 style={{fontSize:14,fontWeight:700,margin:0}}>{t.allBookings}</h1>
            <div style={{display:"flex",gap:3}}>
              <div onClick={()=>setCmdK(true)} style={{width:200,padding:"3px 7px",borderRadius:4,border:`1px solid ${th.inputBorder}`,background:th.inputBg,color:th.textMuted,fontSize:10,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"space-between"}}><span>🔍 {t.search}</span><kbd style={{padding:"1px 3px",borderRadius:2,border:`1px solid ${th.cardBorder}`,fontSize:7.5}}>⌘K</kbd></div>
              <button style={{padding:"3px 9px",borderRadius:4,border:"none",cursor:"pointer",background:th.gradient,color:th.gradientText,fontSize:10,fontWeight:700,fontFamily:"'DM Sans',sans-serif"}}>{t.newBooking}</button>
            </div>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(105px,1fr))",gap:4,padding:"7px 12px",borderBottom:`1px solid ${th.divider}`}}>{[{l:t.total,v:bookings.length,c:th.text},{l:t.active,v:bookings.filter(b=>!["delivered","cancelled","quote"].includes(b.status)).length,c:th.accent},{l:t.overdueTasks,v:totalOD,c:totalOD?th.danger:th.success},{l:t.avgMargin,v:(()=>{const cl=bookings.filter(b=>!hasMixedCcy(b));const r=cl.reduce((s,b)=>s+getSell(b),0);const c_=cl.reduce((s,b)=>s+getBuy(b),0);return r?Math.round((r-c_)/r*100)+"%":"—";})(),c:th.warning}].map((s,i)=><div key={i} style={{background:th.cardBg,border:`1px solid ${th.cardBorder}`,borderRadius:6,padding:"6px 8px",boxShadow:th.shadow}}><div style={{color:th.textMuted,fontSize:8,fontWeight:600,textTransform:"uppercase"}}>{s.l}</div><div style={{color:s.c,fontSize:15,fontWeight:700,fontFamily:"'Space Mono',monospace"}}>{s.v}</div></div>)}</div>
          <div style={{display:"flex",gap:3,padding:"5px 12px",borderBottom:`1px solid ${th.divider}`,alignItems:"center"}}>
            {[{key:"overdue",label:t.overdueTasks,count:bookings.filter(b=>getODTasks(b).length>0).length,c:th.danger}].filter(e=>e.count>0).map(ex=><button key={ex.key} onClick={()=>setExc(exc===ex.key?null:ex.key)} style={{padding:"2px 6px",borderRadius:8,border:`1px solid ${exc===ex.key?ex.c:th.cardBorder}`,background:exc===ex.key?`${ex.c}12`:"transparent",color:exc===ex.key?ex.c:th.textSecondary,fontSize:9.5,cursor:"pointer",fontFamily:"'DM Sans',sans-serif"}}>{ex.label} <span style={{fontWeight:700}}>{ex.count}</span></button>)}
            <select value={fSt} onChange={e=>setFSt(e.target.value)} style={{marginLeft:"auto",padding:"2px 4px",borderRadius:3,border:`1px solid ${th.inputBorder}`,background:th.inputBg,color:th.text,fontSize:9,fontFamily:"'DM Sans',sans-serif",boxSizing:"border-box"}}><option value="all">{t.all}</option>{["quote","confirmed","loading","transit","arrived","delivered"].map(s=><option key={s} value={s}>{t[statusKey[s]]}</option>)}</select>
          </div>
          <div style={{flex:1,overflowY:"auto"}}>
            <div style={{display:"grid",gridTemplateColumns:"85px 30px 1fr 100px 55px 65px 42px 55px",padding:"4px 12px",borderBottom:`1px solid ${th.divider}`,background:th.surfaceAlt,position:"sticky",top:0,zIndex:5}}>{["Ref",t.direction,lang==="tr"?"Müşteri":"Customer","Route","ETD",t.progress,t.margin,"Status"].map((h,i)=><span key={i} style={{color:th.textMuted,fontSize:7.5,fontWeight:600,textTransform:"uppercase"}}>{h}</span>)}</div>
            {filtered.map(b=>{const buy=getBuy(b);const sell=getSell(b);const rawM=sell>0?((sell-buy)/sell*100).toFixed(0):null;const mStr=rawM!==null?rawM+"%":"—";const mColor=rawM===null?th.textMuted:parseInt(rawM)>25?th.success:parseInt(rawM)>15?th.warning:th.danger;const dc=dirCfg(b.direction,th);const ss_=stCfg(b.status,th);const prog=getWfProg(b);const od=getODTasks(b).length>0;const sc=b.schedule||{};return(
              <div key={b.id} onClick={()=>setSel(b)} style={{display:"grid",gridTemplateColumns:"85px 30px 1fr 100px 55px 65px 42px 55px",padding:"6px 12px",borderBottom:`1px solid ${th.divider}`,cursor:"pointer",alignItems:"center",background:od?th.overdueBg:"transparent"}} onMouseEnter={e=>e.currentTarget.style.background=od?th.overdueBg:th.hover} onMouseLeave={e=>e.currentTarget.style.background=od?th.overdueBg:"transparent"}>
                <span style={{display:"flex",alignItems:"center",gap:2}}>{od&&<span style={{color:th.danger,fontSize:5}}>●</span>}<span style={{color:th.accent,fontFamily:"'Space Mono',monospace",fontSize:9,fontWeight:600}}>{b.id}</span></span>
                <span style={{color:dc.c,fontSize:7,fontWeight:700,padding:"1px 2px",borderRadius:2,background:`${dc.c}10`,textAlign:"center"}}>{lang==="tr"?dc.tr:dc.en}</span>
                <span style={{color:th.text,fontSize:10,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{b.customer}</span>
                <span style={{color:th.textSecondary,fontSize:8.5,fontFamily:"'Space Mono',monospace"}}>{(b.origin||"").split("(")[1]?.replace(")","")+"→"+(b.destination||"").split("(")[1]?.replace(")","")}</span>
                <span style={{color:th.textSecondary,fontSize:8.5,fontFamily:"'Space Mono',monospace"}}>{fmtDate(sc.etdPlanned)}</span>
                <span style={{display:"flex",alignItems:"center",gap:2}}><div style={{width:30}}><PBar pct={prog.pct} th={th} h={3}/></div><span style={{color:prog.pct===100?th.success:th.textSecondary,fontSize:8.5,fontFamily:"'Space Mono',monospace"}}>{prog.pct}%</span></span>
                <span style={{color:mColor,fontSize:8.5,fontWeight:600,fontFamily:"'Space Mono',monospace"}}>{mStr}</span>
                <span style={{display:"inline-flex",padding:"1px 4px",borderRadius:7,fontSize:7.5,fontWeight:600,color:ss_.c,background:ss_.bg}}>{t[statusKey[b.status]]}</span>
              </div>);})}
          </div>
        </>):<div style={{padding:16,textAlign:"center",color:th.textMuted,fontSize:12}}>{page}</div>}
      </div>
    </div>);
}

function CmdK({bookings,th,t,lang,onSelect,onClose}){const[q,setQ]=useState("");const ref=useRef(null);useEffect(()=>{ref.current?.focus();},[]);const res=q.length>=2?bookings.filter(b=>{const s=q.toLowerCase();return b.id.toLowerCase().includes(s)||b.customer?.toLowerCase().includes(s);}):[];return(<><div style={{display:"flex",alignItems:"center",padding:"7px 9px",borderBottom:`1px solid ${th.divider}`,gap:4}}><span style={{color:th.textMuted,fontSize:11}}>🔍</span><input ref={ref} value={q} onChange={e=>setQ(e.target.value)} placeholder={lang==="tr"?"Booking veya müşteri...":"Search..."} style={{flex:1,border:"none",background:"transparent",color:th.text,fontSize:12,outline:"none",fontFamily:"'DM Sans',sans-serif"}}/><kbd style={{padding:"1px 3px",borderRadius:2,border:`1px solid ${th.cardBorder}`,color:th.textMuted,fontSize:7.5}} onClick={onClose}>ESC</kbd></div><div style={{maxHeight:240,overflowY:"auto"}}>{res.map(b=>{const dc=dirCfg(b.direction,th);const prog=getWfProg(b);return<div key={b.id} onClick={()=>onSelect(b)} style={{padding:"5px 9px",cursor:"pointer",borderBottom:`1px solid ${th.divider}`,display:"flex",alignItems:"center",gap:5}} onMouseEnter={e=>e.currentTarget.style.background=th.hover} onMouseLeave={e=>e.currentTarget.style.background="transparent"}><span style={{color:th.accent,fontFamily:"'Space Mono',monospace",fontSize:9.5,fontWeight:600,minWidth:75}}>{b.id}</span><span style={{color:dc.c,fontSize:7,fontWeight:700,padding:"1px 3px",borderRadius:2,background:`${dc.c}12`}}>{lang==="tr"?dc.tr:dc.en}</span><span style={{color:th.text,fontSize:10,flex:1}}>{b.customer}</span><span style={{color:th.textMuted,fontSize:9}}>{prog.pct}%</span></div>;})}</div></>);}
