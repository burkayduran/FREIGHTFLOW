# Changelog

All notable changes to FreightFlow are documented here.

---

## v10 Final (Current)

### Added
- New Booking Wizard: `region` field (europe / asia / mena) — required
- Semantic workflow task codes: `gate_in_confirmed`, `customs_closed`, `draft_bl_prepared`, `si_submitted`, `vgm_received`, `ar_paid`
- `TASK_CODE` constants and `findTaskByCode()` helper
- `CargoLineHsField` stale state fix via `useEffect`

### Changed
- Cargo line HS (`containers[].cargoLines[].hsCode`) is now the primary HS data source
- Booking-level HS is fallback / backward compatibility only
- Draft BL save uses semantic `draft_bl_prepared` code match
- CY cutoff risk → `gate_in_confirmed` task (semantic)
- ETD <48h risk → `customs_closed` task (semantic)
- `notify = booking.notifyParty || booking.agent || ""`

### Fixed
- Region filter now applies to newly created bookings immediately
- Stale HS state in cargo line fields after booking change

---

## v10 Patched

### Added
- `isAdmin` and `allowedRegions` fields to USERS model
- `region` field to MOCK_BOOKINGS
- `visibleBookings` filter: non-admin users see only their `allowedRegions`
- Sidebar shows active user's region and visible booking count
- Semantic task code scaffolding (partial)

### Removed
- `AdminPanel` function and all orphan admin code
- Separate admin page/route

### Fixed
- `getDraftBlData`: notify priority (notifyParty first, agent fallback)
- Seal read from `container.seal`
- Multi cargo line support in Draft BL

---

## v9.4 Patch (15-item)

### Added
- New Booking Wizard (5 steps: Type → Info → Schedule → Container → Draft BL)
- `cargoLines[]` structure per container
- `+ Satır` button for adding cargo lines in wizard
- HS dataset inlined into `App.jsx` (removed external `hsData.js` dependency)

### Changed
- `emptyEarliest` label → "Ardiyesiz giriş" (TR and EN)
- `recomputeWorkflow`: SLA dates computed from ETD/ETA dynamically
- `deriveExceptions`: semantic task code matching

### Fixed
- `toDateSafe` helper for invalid date strings
- `saveDraftBlDocument`: semantic task match instead of hardcoded index
- `HsCodeField`: `useEffect` for booking change sync

---

## v9.3 — HS Code Search

### Added
- `hsData.js`: 6,842 HS codes (level 4 and 6) from harmonized-system dataset
- `normalizeStr()`: apostrophe and special character normalization
- `searchHs()`: search by code prefix or multi-word description
- `HsCodeField` component: booking-level HS search/select with clear button
- Draft BL HTML template: HS CODE row

### Changed
- `getDraftBlData`: reads `hsCode` and `hsDescription` from booking
- General section in DetailTab: HS Code field added after Commodity

---

## v9.2 — Draft BL Workflow

### Added
- `getDraftBlData(booking)`: extracts BL data from booking
- `getDraftBlMissingFields(booking)`: checks 15 required fields
- `generateDraftBlHtml(data, form)`: generates HTML BL document with DRAFT watermark
- `saveDraftBlDocument(booking, html, cu)`: saves to docs[], writes audit log, closes workflow task
- Draft BL card in Booking Detail > Detail tab:
  - Readiness progress bar (x/15)
  - Missing field badges
  - BL fields modal (Place of Issue, Issue Date, No. of Originals, Freight Payable At)
  - Preview modal with "Onayla & Kaydet" button
